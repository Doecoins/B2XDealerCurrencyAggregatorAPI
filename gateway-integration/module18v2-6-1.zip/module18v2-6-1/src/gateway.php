<?php

namespace Ethereumico\Epg;

require $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->base_path . '/vendor/autoload.php';
require_once $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->base_path . '/vendor/prospress/action-scheduler/action-scheduler.php';

use Web3\Web3;
use Web3\Providers\HttpProvider;
use Web3\RequestManagers\HttpRequestManager;
use Web3\Contract;
use Web3\Utils;
use WC_Logger;
use WC_Order;
use WC_Payment_Gateway;
use WC_Admin_Settings;

function ether_and_erc20_tokens_woocommerce_payment_gateway_getGatewayContractAddress($blockchainNetwork) {
    switch ($blockchainNetwork) {
        case 'mainnet' :
            return '0x3E0371bcb61283c036A48274AbDe0Ab3DA107a50';
        case 'ropsten' :
            return '0x4028d9F65B65517eAf4c541CfBd3d0D5E4b411cC';
    }
    return __('Unknown network name in configuration settings', 'ether-and-erc20-tokens-woocommerce-payment-gateway');
}

function ether_and_erc20_tokens_woocommerce_payment_gateway_getGatewayContractAddress_v1($blockchainNetwork) {
    switch ($blockchainNetwork) {
        case 'mainnet' :
            return '0xCF19CfEE14E161d339a084993B2cb18b7eAEc773';
        case 'ropsten' :
            return '0x77E4c6fC30862F066642206697c085b5D2E24CBb';
    }
    return __('Unknown network name in configuration settings', 'ether-and-erc20-tokens-woocommerce-payment-gateway');
}

function ether_and_erc20_tokens_woocommerce_payment_gateway_getEthValueByOrderId($order_id, $custom_currency) {
    $order = new WC_Order($order_id);
    $currency = get_woocommerce_currency();
    if ( 'yes' != $custom_currency && $currency != 'MYC' && 
        !(function_exists('mycred_point_type_exists') && mycred_point_type_exists( $currency )) 
    ) {
        if (is_callable(array($order, 'get_meta'))) {
            return doubleval($order->get_meta('_epg_eth_value'));
        }
        return doubleval(get_post_meta($order_id, '_epg_eth_value', true));
    }
    return $order->get_total();
}

function ether_and_erc20_tokens_woocommerce_payment_gateway_getEthRateByOrderId($order_id, $custom_currency) {
    $currency = get_woocommerce_currency();
    if ( 'yes' != $custom_currency && $currency != 'MYC' && 
        !(function_exists('mycred_point_type_exists') && mycred_point_type_exists( $currency )) 
    ) {
        $order = new WC_Order($order_id);
        if (is_callable(array($order, 'get_meta'))) {
            return doubleval($order->get_meta('epg_eth_rate'));
        }
        return doubleval(get_post_meta($order_id, 'epg_eth_rate', true));
    }
    return 1;
}

function _ether_and_erc20_tokens_woocommerce_payment_gateway_double_int_multiply($dval, $ival) {
    $dval = doubleval($dval);
    $ival = intval($ival);
    $dv1 = floor($dval);
    $ret = new \phpseclib\Math\BigInteger(intval($dv1));
    $ret = $ret->multiply(new \phpseclib\Math\BigInteger($ival));
    if ($dv1 === $dval) {
        return $ret;
    }
    $dv2 = $dval - $dv1;
    $iv1 = intval($dv2 * $ival);
    $ret = $ret->add(new \phpseclib\Math\BigInteger($iv1));
    return $ret;
}

function ether_and_erc20_tokens_woocommerce_payment_gateway_getEthValueWithDustByOrderId($eth_value, $order_id) {
    $eth_value_wei0 = _ether_and_erc20_tokens_woocommerce_payment_gateway_double_int_multiply($eth_value, pow(10, 18));
    $a10000000000 = new \phpseclib\Math\BigInteger(10000000000);
    list($eth_value_wei1, $_) = $eth_value_wei0->divide($a10000000000);
    $eth_value_wei = $eth_value_wei1->multiply($a10000000000);
    $diff = $eth_value_wei0->subtract($eth_value_wei);
    $order_id_wei = new \phpseclib\Math\BigInteger(intval($order_id));
    if ($order_id_wei->compare($diff) < 0) {
        // compensate replacement of these weis with order_id
        $eth_value_wei = $eth_value_wei->add($a10000000000);
    }
    // add order_id as a dust
    $eth_value_wei = $eth_value_wei->add($order_id_wei);
    list($eth_value_wei_1, $eth_value_wei_2) = $eth_value_wei->divide(new \phpseclib\Math\BigInteger(pow(10, 18)));
    return array($eth_value_wei->toString(), $eth_value_wei_1->toString() . '.' . sprintf("%'.018d", intval($eth_value_wei_2->toString())));
}

/**
 * 
 * @param type $tokens_supported
 * @param type $tokenAddress
 * @param number $eth_rate 1 USD in ETH
 * @return number Token rate in ETH
 */
function ether_and_erc20_tokens_woocommerce_payment_gateway_getTokenRate($tokens_supported, $tokenAddress, $eth_rate) {
    $tokensArr = explode(",", $tokens_supported);
    if (!$tokensArr) {
        return null;
    }
    $currency = get_woocommerce_currency(); // USD,EUR, ...
    foreach ($tokensArr as $tokenStr) {
        $tokenPartsArr = explode(":", $tokenStr);
        if (count($tokenPartsArr) != 3) {
            continue;
        }
        $address = $tokenPartsArr[1];
        if (strtolower($tokenAddress) != strtolower($address)) {
            continue;
        }
        $rate = $tokenPartsArr[2];
        $pos = strpos($rate, $currency);
        if ($pos !== FALSE) {
            $rate = substr($rate, 0, strlen($rate) - strlen($currency));
            // e.g. rate=0.1USD => eth_rate=0.01ETH
            return $rate * $eth_rate;
        }
        return $rate;
    }
    return null;
}

// adjust token rates given in the base currency, not in Ether
function ether_and_erc20_tokens_woocommerce_payment_gateway_get_tokens_supported($tokens_supported, $order_id, $custom_currency) {
    $eth_rate = ether_and_erc20_tokens_woocommerce_payment_gateway_getEthRateByOrderId($order_id, $custom_currency);
    $tokens_supported_new = [];
    $tokensArr = explode(",", $tokens_supported);
    if (!$tokensArr) {
        return implode(',', $tokens_supported_new);
    }
    $currency = get_woocommerce_currency(); // USD,EUR, ...
    foreach ($tokensArr as $tokenStr) {
        $tokenPartsArr = explode(":", $tokenStr);
        if (count($tokenPartsArr) != 3) {
            continue;
        }
        $symbol = $tokenPartsArr[0];
        $address = $tokenPartsArr[1];
        $rate = $tokenPartsArr[2];
        $pos = strpos($rate, $currency);
        if ($pos !== FALSE) {
            $rate = doubleval(substr($rate, 0, strlen($rate) - strlen($currency)));
            // e.g. rate=1USD, eth_rate=0.01ETH => 0.01
            $rate = $rate * $eth_rate;
        }
        $tokens_supported_new[] = $symbol . ':' . $address . ':' . $rate;
    }
    return implode(',', $tokens_supported_new);
}

function ether_and_erc20_tokens_woocommerce_payment_gateway_call_gateway_method($method, $order_id, $providerUrl, $blockchainNetwork, $marketAddress) {
    $abi = $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->gatewayContractABI;
    $contract = new Contract(new HttpProvider(new HttpRequestManager($providerUrl, 10/* seconds */)), $abi);

    $contractAddress = ether_and_erc20_tokens_woocommerce_payment_gateway_getGatewayContractAddress($blockchainNetwork);
    $ret = null;
    $callback = function($error, $result) use(&$ret) {
        if ($error !== null) {
            $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log($error);
            return;
        }
        $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log("RESULT: " . print_r($result, true));
        foreach ($result as $key => $res) {
            $ret = $res;
            $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log("key: " . $key . "; ret: " . $ret);
            break;
        }
    };
    // call contract function
    $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log(
        sprintf(
            __('call contract %s method %s for market %s for order %s', 'ether-and-erc20-tokens-woocommerce-payment-gateway'), $contractAddress, $method, $marketAddress, $order_id
        )
    );
    $contract->at($contractAddress)->call($method, $marketAddress, $order_id, $callback);
    $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log("ret2: " . $ret);
    return $ret;
}

function ether_and_erc20_tokens_woocommerce_payment_gateway_call_gateway_method_v1($method, $order_id, $providerUrl, $blockchainNetwork, $marketAddress) {
    $abi = $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->gatewayContractABI_v1;
    $contract = new Contract(new HttpProvider(new HttpRequestManager($providerUrl, 10/* seconds */)), $abi);

    $contractAddress = ether_and_erc20_tokens_woocommerce_payment_gateway_getGatewayContractAddress_v1($blockchainNetwork);
    $ret = null;
    $callback = function($error, $result) use(&$ret) {
        if ($error !== null) {
            $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log($error);
            return;
        }
        $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log("RESULT: " . print_r($result, true));
        foreach ($result as $key => $res) {
            $ret = $res;
            $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log("key: " . $key . "; ret: " . $ret);
            break;
        }
    };
    // call contract function
    $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log(
        sprintf(
            __('call contract %s method %s for market %s for order %s', 'ether-and-erc20-tokens-woocommerce-payment-gateway'), $contractAddress, $method, $marketAddress, $order_id
        )
    );
    $contract->at($contractAddress)->call($method, $marketAddress, $order_id, $callback);
    $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log("ret2: " . $ret);
    return $ret;
}

function ether_and_erc20_tokens_woocommerce_payment_gateway_get_token_decimals($tokenAddress, $providerUrl) {
    $abi = $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->erc20ContractABI;
    $contract = new Contract(new HttpProvider(new HttpRequestManager($providerUrl, 10/* seconds */)), $abi);

    $ret = null;
    $callback = function($error, $result) use(&$ret) {
        if ($error !== null) {
            $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log($error);
            return;
        }
        $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log("RESULT: " . print_r($result, true));
        foreach ($result as $key => $res) {
            $ret = $res;
            $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log("key: " . $key . "; ret: " . $ret);
            break;
        }
    };
    // call contract function
    $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log(
        sprintf(
            __('call contract %s method decimals', 'ether-and-erc20-tokens-woocommerce-payment-gateway'), $tokenAddress
        )
    );
    $contract->at($tokenAddress)->call("decimals", $callback);
    $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log("ret2: " . $ret);
    return $ret;
}

function ether_and_erc20_tokens_woocommerce_payment_gateway_getPaymentInfo($order_id, $providerUrl, $blockchainNetwork, $marketAddress) {
    $currencyPayment = ether_and_erc20_tokens_woocommerce_payment_gateway_call_gateway_method("getCurrencyPayment", $order_id, $providerUrl, $blockchainNetwork, $marketAddress);
    if (null === $currencyPayment) {
        return null;
    }
    if (!($currencyPayment === "0x0000000000000000000000000000000000000000" ||
        $currencyPayment === "0x")
    ) {
        $valuePayment = ether_and_erc20_tokens_woocommerce_payment_gateway_call_gateway_method("getValuePayment", $order_id, $providerUrl, $blockchainNetwork, $marketAddress);
        if (null !== $valuePayment) {
            $valuePayment_f = doubleval($valuePayment->toString());
            return [$currencyPayment => $valuePayment_f];
        }
    }

    // Backwards compatibility with first plugin version
    $currencyPayment = ether_and_erc20_tokens_woocommerce_payment_gateway_call_gateway_method_v1("getCurrencyPayment", $order_id, $providerUrl, $blockchainNetwork, $marketAddress);
    if (null === $currencyPayment) {
        return null;
    }
    if (!($currencyPayment === "0x0000000000000000000000000000000000000000" ||
        $currencyPayment === "0x")
    ) {
        $valuePayment = ether_and_erc20_tokens_woocommerce_payment_gateway_call_gateway_method_v1("getValuePayment", $order_id, $providerUrl, $blockchainNetwork, $marketAddress);
        if (null !== $valuePayment) {
            $valuePayment_f = doubleval($valuePayment->toString());
            return [$currencyPayment => $valuePayment_f];
        }
    }
    return null;
}

function ether_and_erc20_tokens_woocommerce_payment_gateway_check_gateway_class ($order_id) {
    $payment_gateway = wc_get_payment_gateway_by_order( $order_id );
    if (!$payment_gateway) {
        return false;
    }
    return $payment_gateway instanceof \Ethereumico\Epg\Gateway;
}

/**
 * WooCommerce gateway class implementation.
 */
class Gateway extends WC_Payment_Gateway {

    /**
     * Constructor, set variables etc. and add hooks/filters
     */
    function __construct() {
        $this->id = 'ether-and-erc20-tokens-woocommerce-payment-gateway';
        $this->method_title = __('Pay with Ether or ERC20 token', 'ether-and-erc20-tokens-woocommerce-payment-gateway');
        $this->method_description = __('Pay with Ether or ERC20 token provides customers a way to pay with MetaMask or any other Ethereum wallet.', 'ether-and-erc20-tokens-woocommerce-payment-gateway');
        $this->has_fields = true;
        $this->supports = array(
            'products',
        );
        $this->view_transaction_url = 'https://etherscan.io/tx/%s';

        // Load the settings.
        $this->init_settings();

        // Load the form fields.
        $this->init_form_fields();

        // Set the public facing title according to the user's setting.
        $this->title = $this->get_setting_('title', __('Pay with ETH', 'ether-and-erc20-tokens-woocommerce-payment-gateway'));
//        $this->description = $this->settings['short_description'];
        $this->description = $this->method_description;

        // Save options from admin forms.
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'verify_api_connection'));

        // Show gateway icon.
//        add_filter('woocommerce_gateway_icon', array($this, 'show_icons'), 10, 2);

        // Show payment instructions on thank you page.
        add_action('woocommerce_thankyou_ether-and-erc20-tokens-woocommerce-payment-gateway', array($this, 'thank_you_page'));
        
        add_action( 'wp_enqueue_scripts', array( $this, 'register_plugin_styles' ) );
        
        add_action( 'woocommerce_order_status_on-hold', array( $this, 'order_on_hold_handler' ) );
        add_action( 'woocommerce_order_status_cancelled', array( $this, 'order_cancelled_handler' ) );
        add_action( 'before_delete_post', array( $this, 'before_delete_post_handler' ) );
//        add_action( 'ether_and_erc20_tokens_woocommerce_payment_gateway_complete_order', array( $this, 'complete_order' ), 0, 1 );
    }
    
    private function get_setting_($setting, $default = '') {
        return isset($this->settings[$setting]) ? $this->settings[$setting] : $default;
    }
    
    public function order_on_hold_handler($order_id) {
        if (!ether_and_erc20_tokens_woocommerce_payment_gateway_check_gateway_class ($order_id)) {
            return;
        }
        $this->enqueue_complete_order_task($order_id);
    }
    
    public function order_cancelled_handler($order_id) {
        if (!ether_and_erc20_tokens_woocommerce_payment_gateway_check_gateway_class ($order_id)) {
            return;
        }
        $this->cancel_complete_order_task($order_id);
    }
    
    public function before_delete_post_handler($order_id) {
        global $post_type;

        if($post_type !== 'shop_order') {
            return;
        }
        if (!ether_and_erc20_tokens_woocommerce_payment_gateway_check_gateway_class ($order_id)) {
            return;
        }
        $this->cancel_complete_order_task($order_id);
    }
    
    public function enqueue_complete_order_task($order_id, $offset = 0/* seconds */) {
        $this->cancel_complete_order_task($order_id);
        $timestamp = time() + $offset;
        $hook = 'ether_and_erc20_tokens_woocommerce_payment_gateway_complete_order';
        $args = array($order_id);
        $task_id = as_schedule_single_action( $timestamp, $hook, $args );
        $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log("Task complete_order with id $task_id scheduled for order: $order_id");
    }
    public function cancel_complete_order_task($order_id) {
        $hook = "ether_and_erc20_tokens_woocommerce_payment_gateway_complete_order";
        $args = array($order_id);
        as_unschedule_action( $hook, $args );
        $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log("Task complete_order unscheduled for order: $order_id");
    }

    public function complete_order($order_id) {
        $tokens_supported = esc_attr($this->get_setting_('tokens_supported'));
        $providerUrl = $this->getWeb3Endpoint();
        $blockchainNetwork = $this->getBlockchainNetwork();;
        $marketAddress = $this->getMarketAddress();
        try {
            $paymentSuccess = $this->check_tx_status(
                $order_id, $tokens_supported, $this->getOrderExpiredTimeout(), $providerUrl, $blockchainNetwork, $marketAddress, true
            );
        } catch(Exception $ex) {
            $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log("complete_order: " . $ex->getMessage());
        }
        if (!$paymentSuccess) {
            // re-enqueue itself to check later
            $this->enqueue_complete_order_task($order_id, 1 * 60);
        }
    }

    public function complete_order_internal($order_id) {
        $tokens_supported = esc_attr($this->get_setting_('tokens_supported'));
        $providerUrl = $this->getWeb3Endpoint();
        $blockchainNetwork = $this->getBlockchainNetwork();
        $marketAddress = $this->getMarketAddress();
        try {
            $paymentSuccess = $this->check_tx_status(
                $order_id, $tokens_supported, $this->getOrderExpiredTimeout(), $providerUrl, $blockchainNetwork, $marketAddress, true
            );
        } catch(Exception $ex) {
            $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log("complete_order: " . $ex->getMessage());
        }
        if ($paymentSuccess) {
            $this->cancel_complete_order_task($order_id);
        }
    }

//    /**
//     * Output the logo.
//     *
//     * @param  string $icon    The default WC-generated icon.
//     * @param  string $gateway The gateway the icons are for.
//     *
//     * @return string          The HTML for the selected iconsm or empty string if none
//     */
//    public function show_icons($icon, $gateway) {
//        if ($this->id !== $gateway) {
//            return $icon;
//        }
//        $img_url = $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->base_url . '/img/ethereum-icon.png';
//        return '<img src="' . esc_attr($img_url) . '" width="25" height="25">';
//    }

    /**
     * Get gateway icon.
     * @return string
     */
    public function get_icon() {
        $img_url = $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->base_url . '/img/ethereum-icon.png';
        $icon_html ='<img src="' . esc_attr($img_url) . '" width="25" height="25">';
        return apply_filters( 'woocommerce_gateway_icon', $icon_html, $this->id );
    }

    /**
     * Tell the user how much their order will cost if they pay by ETH.
     */
    public function payment_fields() {
        $total = WC()->cart->total;
        $currency = get_woocommerce_currency();
        try {
            $eth_rate = null;
            $eth_value = null;
            $eth_value_no_markup = null;
            $custom_currency = $this->get_setting_('custom_currency', 'no');
            if ( 'yes' != $custom_currency && $currency != 'MYC' && 
                !(function_exists('mycred_point_type_exists') && mycred_point_type_exists( $currency )) 
            ) {
                $fiat_rate_provider = esc_attr($this->get_setting_('fiat_rate_provider'));
                $currencyRateSource = CurrencyRateSource_Factory::create($fiat_rate_provider, $this->settings);
                $convertor = new CurrencyConvertor($currency, 'ETH', $currencyRateSource);
                $eth_value_no_markup = $convertor->convert($total);
                $eth_value = $this->apply_markup($eth_value_no_markup);
                $eth_rate = $convertor->get_exchange_rate();
            }
            // Set the value in the session so we can log it against the order.
            WC()->session->set(
                'epg_calculated_value', array(
                    'eth_value' => $eth_value,
                    // 1 USD in ETH
                    'eth_rate' => $eth_rate,
                    'timestamp' => time(),
                )
            );
            $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log(
                "Total value ($currency): " . $total
            );
            $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log(
                'Exchange rate: ' . $eth_rate . ' Ether/' . $currency
            );
            $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log(
                'Total value without markup in Ether: ' . $eth_value_no_markup
            );
            $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log(
                'Total value with markup in Ether: ' . $eth_value
            );
            $markup_percent = $this->get_setting_('markup_percent', '0');
            $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log(
                'Markup Percent: ' . $markup_percent
            );
            $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log(
                'Markup value in Ether: ' . ($eth_value - $eth_value_no_markup)
            );
            echo '<p class="epg-eth-pricing-note"><strong>';
            $tokens_supported = esc_attr($this->get_setting_('tokens_supported'));
            if (empty(trim($tokens_supported))) {
                printf(__('Payment of %s ETH will be due.', 'ether-and-erc20-tokens-woocommerce-payment-gateway'), $eth_value);
            } else {
                $disable_ether = $this->get_setting_('disable_ether', 'no');
                if ('yes' != $disable_ether) {
                    printf(__('Payment of %s ETH or an equivalent in ERC20 supported tokens will be due.', 'ether-and-erc20-tokens-woocommerce-payment-gateway'), $eth_value);
                } else {
                    printf(__('Payment of %s ETH in a supported ERC20 tokens equivalent will be due.', 'ether-and-erc20-tokens-woocommerce-payment-gateway'), $eth_value);
                }
            }
            echo '</strong></p>';
        } catch (\Exception $e) {
            $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log(
                sprintf(
                    __('Problem performing currency conversion: %s', 'ether-and-erc20-tokens-woocommerce-payment-gateway'), $e->getMessage()
                )
            );
            echo '<div class="woocommerce-NoticeGroup woocommerce-NoticeGroup-checkout">';
            echo '<ul class="woocommerce-error">';
            echo '<li>';
            _e(
                'Unable to provide an order value in ETH at this time. Please contact support.', 'ether-and-erc20-tokens-woocommerce-payment-gateway'
            );
            echo '</li>';
            echo '</ul>';
            echo '</div>';
        }
    }

    /**
     * Checks that not too much time has passed since we quoted them a price.
     */
    public function validate_fields() {
        $price_info = WC()->session->get('epg_calculated_value');
        // Prices quoted at checkout must be re-calculated if more than 15
        // minutes have passed.
        $validity_period = apply_filters('epg_checkout_validity_time', 900);
        if (!is_array($price_info) || ($price_info['timestamp'] + $validity_period < time())) {
            wc_add_notice(__('ETH price quote has been updated, please check and confirm before proceeding.', 'ether-and-erc20-tokens-woocommerce-payment-gateway'), 'error');
            return false;
        }
        return true;
    }

    /**
     * Mark up a price by the configured amount.
     *
     * @param  float $price  The price to be marked up.
     *
     * @return float         The marked up price.
     */
    private function apply_markup($price) {
        $markup_percent = doubleval($this->get_setting_('markup_percent', '0'));
        $multiplier = ( $markup_percent / 100 ) + 1;
        return round($price * $multiplier, 5, PHP_ROUND_HALF_UP);
    }

    /**
     * Mark up a price by the configured amount.
     *
     * @param  float $price  The price to be marked up.
     *
     * @return float         The marked up price.
     */
    private function apply_markup_token($price) {
        $markup_percent_token = doubleval($this->get_setting_('markup_percent_token', '0'));
        $multiplier = ( $markup_percent_token / 100 ) + 1;
        $markup_percent = doubleval($this->get_setting_('markup_percent', '0'));
        $divider = ( $markup_percent / 100 ) + 1;
        return round(doubleval($price) * $multiplier / $divider, 5, PHP_ROUND_HALF_UP);
    }

    /**
     * Initialise Gateway Settings Form Fields
     */
    function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title' => __('Enable / disable', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'label' => __('Enable payment with Ether or ERC20 tokens', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'type' => 'checkbox',
                'description' => '',
                'default' => 'no',
            ),
        );
        $tokens_supported = esc_attr($this->get_setting_('tokens_supported'));
        if (empty(trim($tokens_supported))) {
            $title = __('Pay with ETH', 'ether-and-erc20-tokens-woocommerce-payment-gateway');
        } else {
            $title = __('Pay with ETH or ERC20 token', 'ether-and-erc20-tokens-woocommerce-payment-gateway');
        }
        $this->form_fields += array(
            'basic_settings' => array(
                'title' => __('Basic settings', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'type' => 'title',
                'description' => '',
            ),
            'debug' => array(
                'title' => __('Enable debug mode', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'label' => __('Enable only if you are diagnosing problems.', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'type' => 'checkbox',
                'description' => sprintf(__('Log interactions inside <code>%s</code>', 'ether-and-erc20-tokens-woocommerce-payment-gateway'), wc_get_log_file_path($this->id)),
                'default' => 'no',
            ),
            'title' => array(
                'title' => __('Title', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'type' => 'text',
                'description' => __('This controls the name of the payment option that the user sees during checkout.', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'default' => $title,
            ),
//            'short_description' => array(
//                'title' => __('Short description', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
//                'type' => 'textarea',
//                'description' => __('This controls the description of the payment option that the user sees during checkout.', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
//                'default' => 'Pay with your Ether (ETH) or some ERC20 token.',
//            ),
        );
        $this->form_fields += array(
            'api_credentials' => array(
                'title' => __('API credentials', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'type' => 'title',
                'description' => '',
            ),
            'fiat_rate_provider' => array(
                'title' => __('Fiat Rate Provider', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'type' => 'select',
                'description' => sprintf(__('<p>Choose the Ether to fiat currency rate API provider. For the %3$s option you need to specify the %4$s setting value. The %1$s option uses the free %2$s you do not need to register or pay, but is limited to EUR fiat currency only.</p>', 'ether-and-erc20-tokens-woocommerce-payment-gateway')
                    , __('B²X Dealer Blockchain Currency Aggregator API', 'ether-and-erc20-tokens-woocommerce-payment-gateway')
                    , '<a href="https://github.com/Doecoins/B2XDealerCurrencyAggregatorAPI" target="_blank">' . __('API', 'ether-and-erc20-tokens-woocommerce-payment-gateway') . '</a>'
                    , __('Cryptocompare API', 'ether-and-erc20-tokens-woocommerce-payment-gateway')
                    , __('Cryptocompare API Key', 'ether-and-erc20-tokens-woocommerce-payment-gateway')
                ),
                'default' => 'fiat_rate_provider_cryptocompare_api_key',
                'options' => array(
                    'fiat_rate_provider_cryptocompare_api_key' => __('Cryptocompare API', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                    'fiat_rate_provider_B2XDealerCurrencyAggregatorAPI' => __('B²X Dealer Blockchain Currency Aggregator API', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                ),
            ),
            'cryptocompare_api_key' => array(
                'title' => __('Cryptocompare API Key', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'type' => 'text',
                'description' => sprintf(__('<p>The API key for the <a target="_blank" href="%s">%s</a>. You need to register on this site to obtain it.</p>', 'ether-and-erc20-tokens-woocommerce-payment-gateway'), 'https://min-api.cryptocompare.com', 'https://min-api.cryptocompare.com'),
                'default' => '',
            ),
            'infura_api_key' => array(
                'title' => __('Infura API Key', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'type' => 'text',
                'description' => sprintf(__('<p>The API key for the <a target="_blank" href="%s">%s</a>. You need to register on this site to obtain it.</p>', 'ether-and-erc20-tokens-woocommerce-payment-gateway'), 'https://infura.io/register', 'https://infura.io/'),
                'default' => '',
            ),
        );
        $this->form_fields += array(
            'payment_details' => array(
                'title' => __('Payment details', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'type' => 'title',
                'description' => '',
            ),
            'payment_address' => array(
                'title' => __('Your ethereum address', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'type' => 'text',
                'description' => __('The ethereum address payment should be sent to. Make sure to use one address per one online store. Do not use one address for two or more stores! Also, make sure to use a ERC20 tokens compatible wallet if you are planning to accept it!', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'default' => '',
            ),
            'tokens_supported' => array(
                'title' => __('Supported ERC20 tokens list', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'type' => 'textarea',
                'description' => __('Provide a list of tokens you want to support. It should be in a format like this: Token_symbol1:token_eth_address1:token_price_eth1,Token_symbol2:token_eth_address2:token_price_eth2. For example: TSX:0xe762Da33bf2b2412477c65b01f46D923A7Ef5794:0.001,EOS:0x86Fa049857E0209aa7D9e616F7eb3b3B78ECfdb0:0.01054550. For custom WooCommerce currency stores the token_price is in the custom currency instead of Ether.', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'default' => '',
            ),
            'disable_ether' => array(
                'title' => __('Disable Ether', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'label' => __('Disallow customer to pay with Ether', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'type' => 'checkbox',
                'description' => __('This option is useful to accept only some token. It is an advanced option. Use with care.', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'default' => 'no',
            ),
            'markup_percent' => array(
                'title' => __('Mark Ether price up by %', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'description' => __('To help cover currency fluctuations the plugin can automatically mark up converted rates for you. These are applied as percentage markup, so a 1ETH value with a 1.00% markup will be presented to the customer as 1.01ETH.', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'default' => '2.0',
                'type' => 'number',
                'css' => 'width:100px;',
                'custom_attributes' => array(
                    'min' => -100,
                    'max' => 100,
                    'step' => 0.1,
                ),
            ),
            'markup_percent_token' => array(
                'title' => __('Mark ERC20 token price up by %', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'description' => __('To help cover currency fluctuations the plugin can automatically mark up converted rates for you. These are applied as percentage markup, so a 1 ERC20 Token value with a 1.00% markup will be presented to the customer as 1.01 Token.', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'default' => '2.0',
                'type' => 'number',
                'css' => 'width:100px;',
                'custom_attributes' => array(
                    'min' => -100,
                    'max' => 100,
                    'step' => 0.1,
                ),
            ),
        );

        $this->form_fields += array(
            'blockchain_settings' => array(
                'title' => __('Blockchain settings', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'type' => 'title',
                'description' => '',
            ),
            'blockchain_network' => array(
                'title' => __('Blockchain', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'type' => 'text',
                'description' => __('<p>The blockchain used: mainnet or ropsten. Use mainnet in production, and ropsten in test mode.</p>', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'default' => 'mainnet',
            ),
            'gas_limit' => array(
                'title' => __('Gas limit', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'type' => 'number',
                'description' => __('The gas limit for transaction.', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'default' => '200000',
            ),
            'gas_price' => array(
                'title' => __('Gas price, Gwei', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'type' => 'number',
                'description' => __('The gas price for transaction.', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'default' => '21',
            ),
        );

        $this->form_fields += array(
            'advanced_settings' => array(
                'title' => __('Advanced settings', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'type' => 'title',
                'description' => '',
            ),
            'custom_currency' => array(
                'title' => __('Yes / No', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'label' => __('Custom WooCommerce currency', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'type' => 'checkbox',
                'description' => __('Check if custom WooCommerce currency is used in this store', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'default' => 'no',
            ),
        );

        $this->form_fields += array(
            'ads1' => array(
                'title' => __('Need help to configure this plugin?', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'type' => 'title',
                'description' => sprintf(
                    __('Feel free to %1$shire me!%2$s', 'cryptocurrency-product-for-woocommerce')
                    , '<a target="_blank" href="https://www.upwork.com/freelancers/~0134e80b874bd1fa5f">'
                    , '</a>'
                ),
            ),
        );
        $this->form_fields += array(
            'ads2' => array(
                'title' => __('Need help to develop a ERC20 token for your ICO?', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'type' => 'title',
                'description' => sprintf(
                    __('Feel free to %1$shire me!%2$s', 'cryptocurrency-product-for-woocommerce')
                    , '<a target="_blank" href="https://ethereumico.io/product/crowdsale-contract-development/">'
                    , '</a>'
                ),
            ),
        );
        $this->form_fields += array(
            'ads3' => array(
                'title' => __('Want to sell your ERC20/ERC223 ICO token from your ICO site?', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'type' => 'title',
                'description' => sprintf(
                    __('Install the %1$sThe EthereumICO Wordpress plugin%2$s!', 'ether-and-erc20-tokens-woocommerce-payment-gateway')
                    , '<a target="_blank" href="https://ethereumico.io/product/ethereum-ico-wordpress-plugin/">'
                    , '</a>'
                ),
            ),
        );
        $this->form_fields += array(
            'ads4' => array(
                'title' => __('Want to sell ERC20 token for fiat and/or Bitcoin?', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'type' => 'title',
                'description' => sprintf(
                    __('Install the %1$sCryptocurrency Product for WooCommerce plugin%2$s!', 'ether-and-erc20-tokens-woocommerce-payment-gateway')
                    , '<a target="_blank" href="https://ethereumico.io/product/cryptocurrency-wordpress-plugin/">'
                    , '</a>'
                ),
            ),
        );
        $this->form_fields += array(
            'ads5' => array(
                'title' => __('Want to create Ethereum wallets on your Wordpress site?', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'type' => 'title',
                'description' => sprintf(
                    __('Install the %1$sWordPress Ethereum Wallet plugin%2$s!', 'ether-and-erc20-tokens-woocommerce-payment-gateway')
                    , '<a target="_blank" href="https://ethereumico.io/product/wordpress-ethereum-wallet-plugin/">'
                    , '</a>'
                ),
            ),
        );
    }

    /**
     * Do not allow enabling of the gateway without providing a payment address.
     */
    public function validate_enabled_field($key, $value) {
        $post_data = $this->get_post_data();
        if ($value) {
            if (empty($post_data['woocommerce_ether-and-erc20-tokens-woocommerce-payment-gateway_payment_address'])) {
                WC_Admin_Settings::add_error('You must provide an Ethereum address before enabling the gateway');
                return 'no';
            } else {
                return 'yes';
            }
        }
        return 'no';
    }

    /**
     * Output the gateway settings page.
     */
    public function admin_options() {
        ?>
        <h3><?php _e('Pay with Ether or ERC20 token', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></h3>
        <p><?php echo sprintf(__('Your customers will be given instructions about where, and how much to pay. Your orders will be marked as on-hold when they are placed. And as complete when payment is recieved. You can update your orders on the <a href="%s">WooCommerce Orders</a> page.', 'ether-and-erc20-tokens-woocommerce-payment-gateway'), admin_url('edit.php?post_type=shop_order')); ?></p>
        <table class="form-table">
        <?php $this->generate_settings_html(); ?>
        </table><!--/.form-table-->
        <?php
    }

    /**
     * See if the site can be connected to the auto-verification service.
     */
    public function verify_api_connection() {
        
    }

    /**
     * Process the payment.
     *
     * @param int $order_id  The order ID to update.
     */
    function process_payment($order_id) {

        // Load the order.
        $order = new WC_Order($order_id);

        // Retrieve the ETH value.
        $stored_info = WC()->session->get('epg_calculated_value');

        // Add order note.
        $order->add_order_note(sprintf(
                __('Order submitted, and payment with %s requested.', 'ether-and-erc20-tokens-woocommerce-payment-gateway'), 'ETH' // TODO
        ));

        if (is_array($stored_info)) {
            // Store the ETH amount required against the order.
            $eth_value = $stored_info['eth_value'];
            if (!empty($eth_value) && doubleval($eth_value) > 0) {
                update_post_meta($order_id, '_epg_eth_value', $eth_value);
            } else {
                $eth_value = get_post_meta($order_id, '_epg_eth_value', true);
            }
        } else {
            $eth_value = get_post_meta($order_id, '_epg_eth_value', true);
        }
        if (is_array($stored_info)) {
            // Store the ETH amount required against the order.
            $eth_rate = $stored_info['eth_rate'];
            if (!empty($eth_rate) && doubleval($eth_rate) > 0) {
                update_post_meta($order_id, 'epg_eth_rate', $eth_rate);
            } else {
                $eth_rate = get_post_meta($order_id, 'epg_eth_rate', true);
            }
        } else {
            $eth_rate = get_post_meta($order_id, 'epg_eth_rate', true);
        }
        $currency = get_woocommerce_currency();
        $custom_currency = $this->get_setting_('custom_currency', 'no');
        if ( 'yes' == $custom_currency ) {
            $curr = $currency;
            $order->add_order_note(sprintf(
                __('Order value calculated as %f %s', 'ether-and-erc20-tokens-woocommerce-payment-gateway'), $order->get_total(), $curr
            ));
        } else {
            if ( $currency != 'MYC' && 
                !(function_exists('mycred_point_type_exists') && mycred_point_type_exists( $currency )) 
            ) {
                $order->add_order_note(sprintf(
                    __('Order value calculated as %f %s', 'ether-and-erc20-tokens-woocommerce-payment-gateway'), $eth_value, 'ETH' // TODO
                ));
            } else {
                // myCRED Point Based Store
                $curr = mycred_get_point_type_name( MYCRED_DEFAULT_TYPE_KEY, false );
                $order->add_order_note(sprintf(
                    __('Order value calculated as %f %s', 'ether-and-erc20-tokens-woocommerce-payment-gateway'), $order->get_total(), $curr
                ));
            }
        }

        // Place the order on hold.
        $order->update_status('on-hold', __('Awaiting payment.', 'ether-and-erc20-tokens-woocommerce-payment-gateway'));

        // Reduce stock levels.
        if (is_callable('wc_reduce_stock_levels')) {
            wc_reduce_stock_levels($order->get_id());
        } else {
            $order->reduce_order_stock();
        }

        // Remove cart.
        WC()->cart->empty_cart();
        // Redirect the user to the confirmation page.
        if (method_exists($order, 'get_checkout_order_received_url')) {
            $redirect = $order->get_checkout_order_received_url();
        } else {
            if (is_callable(array($order, 'get_id')) &&
                is_callable(array($order, 'get_order_key'))) {
                $redirect = add_query_arg('key', $order->get_order_key(), add_query_arg('order', $order->get_id(), get_permalink(get_option('woocommerce_thanks_page_id'))));
            } else {
                $redirect = add_query_arg('key', $order->order_key, add_query_arg('order', $order->id, get_permalink(get_option('woocommerce_thanks_page_id'))));
            }
        }

        // Return thank you page redirect.
        return array(
            'result' => 'success',
            'redirect' => $redirect,
        );
    }
    
    function check_tx_status(
        $order_id, $tokens_supported, $orderExpiredTimeout
        , $providerUrl, $blockchainNetwork, $marketAddress, $standalone = false
    ) {
        $order = new WC_Order($order_id);
        if (!$order->needs_payment()) {
            if ($standalone) {
                $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log(
                    sprintf(
                        __('Order do not need payment, tx check stopped: %s', 'ether-and-erc20-tokens-woocommerce-payment-gateway'), $order_id
                    )
                );
            }
            return true;
        }
        // WC_DateTime|NULL object if the date is set or null if there is no date.
        $created = $order->get_date_created();
        if ($created) {
            $diff = time() - $created->getTimestamp();
            if ($diff > $orderExpiredTimeout) {
                if ($standalone) {
                    $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log(
                        sprintf(
                            __('Order expired.  Order updated to failed: %s', 'ether-and-erc20-tokens-woocommerce-payment-gateway'), $order_id
                        )
                    );
                    $order->add_order_note(
                        __('Order was expired.', 'ether-and-erc20-tokens-woocommerce-payment-gateway')
                    );
                    $order->update_status('failed', __('Order was expired.', 'ether-and-erc20-tokens-woocommerce-payment-gateway'));
                }
                // stop cron job re-enqueue
                return true;
            }
        }

        $paymentInfo = ether_and_erc20_tokens_woocommerce_payment_gateway_getPaymentInfo($order_id, $providerUrl, $blockchainNetwork, $marketAddress);
        if (!$paymentInfo) {
            // no payment yet
            $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log(
                sprintf(
                    __('No payment found for order: %s', 'ether-and-erc20-tokens-woocommerce-payment-gateway'), $order_id
                )
            );
            return false;
        }

        $paymentSuccess = false;
        $custom_currency = $this->get_setting_('custom_currency', 'no');
        $eth_value = ether_and_erc20_tokens_woocommerce_payment_gateway_getEthValueByOrderId($order_id, $custom_currency);
        $eth_rate = ether_and_erc20_tokens_woocommerce_payment_gateway_getEthRateByOrderId($order_id, $custom_currency);
        $decimals_eth = 1000000000000000000;
        $eth_value_wei = doubleval($eth_value) * $decimals_eth;
        // payment recieved
        foreach ($paymentInfo as $currencyPayment => $valuePayment) {
            $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log(
                sprintf(
                    __('PaymentInfo recieved for order_id=%s. %s: %s. eth_value=%s, eth_value_wei=%s', 'ether-and-erc20-tokens-woocommerce-payment-gateway'), $order_id, $currencyPayment, $valuePayment, $eth_value, $eth_value_wei
                )
            );
            // ETH is encoded as address 0x0000000000000000000000000000000000000001
            if ('0x0000000000000000000000000000000000000001' == $currencyPayment) {
                $paymentSuccess = ($valuePayment >= $eth_value_wei);
            } else {
                // $valuePayment is in some ERC20 token
                $decimals_token = intval(ether_and_erc20_tokens_woocommerce_payment_gateway_get_token_decimals($currencyPayment, $providerUrl)->toString());
                $rate = ether_and_erc20_tokens_woocommerce_payment_gateway_getTokenRate($tokens_supported, $currencyPayment, $eth_rate);
                // check if token is supported
                if (null !== $rate) {
                    $value = round(($valuePayment / pow(10, $decimals_token)) * doubleval($rate), 5, PHP_ROUND_HALF_UP);
                    $value_eth_token = $this->apply_markup_token($eth_value);
                    $paymentSuccess = ($value >= $value_eth_token);
                }
                if (!$paymentSuccess) {
                    $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log(
                        sprintf(
                            'Payment failure for order_id=%s. tokens: %s. token decimals: %s. rate=%s. value=%s. value_eth_token=%s'
                            , $order_id, $tokens_supported, $decimals_token, $rate, $value, $value_eth_token
                        )
                    );
                }
            }
            break;
        }

        if ($paymentSuccess) {
            // Trigger the emails to be registered and hooked.
            WC()->mailer()->init_transactional_emails();

            $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log(
                __('Successful payment notification received. Order updated to pending.', 'ether-and-erc20-tokens-woocommerce-payment-gateway')
            );
            $order->add_order_note(
                __('Successful payment notification received. Order updated to pending.', 'ether-and-erc20-tokens-woocommerce-payment-gateway')
            );
            $order->payment_complete();
        } else {
            $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->log(
                sprintf(
                    __('Non-successful payment notification received. Order updated to failed: %s', 'ether-and-erc20-tokens-woocommerce-payment-gateway'), $order_id
                )
            );
            $order->add_order_note(
                __('Non-successful payment notification received. Order updated to failed.', 'ether-and-erc20-tokens-woocommerce-payment-gateway')
            );
            $order->update_status('failed', __('Non-successful payment notification.', 'ether-and-erc20-tokens-woocommerce-payment-gateway'));
        }
        return $paymentSuccess;
    }
    /**
     * Output the payment information onto the thank you page.
     *
     * @param  int $order_id  The order ID.
     */
    public function thank_you_page($order_id) {
        // set task to check tx state and complete order if needed
        $tokens_supported = esc_attr($this->get_setting_('tokens_supported'));
        
        // try to complete order if payment succeeded
        $this->complete_order_internal($order_id);

        $custom_currency = $this->get_setting_('custom_currency', 'no');
        $eth_value = ether_and_erc20_tokens_woocommerce_payment_gateway_getEthValueByOrderId($order_id, $custom_currency);
        list($eth_value_with_dust, $eth_value_with_dust_str) = ether_and_erc20_tokens_woocommerce_payment_gateway_getEthValueWithDustByOrderId($eth_value, $order_id);
        $payment_summary_token_title = __("The ERC20 token payment consists of two steps.", 'ether-and-erc20-tokens-woocommerce-payment-gateway');
        $payment_summary_token_1 = __("Deposit funds to the payment gateway smart contract in the Ethereum blockchain, and", 'ether-and-erc20-tokens-woocommerce-payment-gateway');
        $payment_summary_token_2 = __("Use this deposit to pay for your order.", 'ether-and-erc20-tokens-woocommerce-payment-gateway');
        $payment_summary_token_3 = __("You have to send two transactions to the Ethereum blockchain: first for deposit and second for the real payment.", 'ether-and-erc20-tokens-woocommerce-payment-gateway');
        $payment_description_title = __("Step 2: Release deposit for payment.", 'ether-and-erc20-tokens-woocommerce-payment-gateway');
        $payment_description = __("Send a command to the payment gateway smart contract to do the actual payment for you. The payment gateway smart contract can not spend your tokens without your command. And nobody except you can send this command to the gateway contract. But note, that if you cancel the order on this step and then decide to pay for this or any other order with the same token again, you'll be asked to approve 0 (zero) amount of tokens first, and only after that you'll be able to approve the desired token amount. It is true even for purchases on other stores that use the same payment gateway. It is due to the ERC20 token internal limitations.", 'ether-and-erc20-tokens-woocommerce-payment-gateway');
        $deposit_description_title = __('Step 1: Deposit funds to the payment gateway smart contract.', 'ether-and-erc20-tokens-woocommerce-payment-gateway');
        $deposit_description = __('This step calls the approve method on the token smart contract to allow the payment gateway contract to spend this amount of tokens on behalf of you. The Amount field is the amount of tokens you are required to pay for this order. The Value field is always 0 (zero) for token payments.', 'ether-and-erc20-tokens-woocommerce-payment-gateway');
        $success_message = __('Payment succeeded!', 'ether-and-erc20-tokens-woocommerce-payment-gateway');
        $success_message_no_metamask = __('Payment succeeded! Reload page if it was not auto reloaded.', 'ether-and-erc20-tokens-woocommerce-payment-gateway');
        $payment_incomplete_message = __('Payment status: not complete.', 'ether-and-erc20-tokens-woocommerce-payment-gateway');
        $payment_deposit_made_message = __('Payment status: deposit made.', 'ether-and-erc20-tokens-woocommerce-payment-gateway');
        $str_unlock_metamask_account = __("This wizard requires the MetaMask browser extension to be installed and your MetaMask account to be unlocked. If you do not want to use MetaMask, just copy and paste Value, Address, and Data fields in your favorite wallet software. Ensure these values are quoted exactly, otherwise we won't be able to reconcile your payment.", 'ether-and-erc20-tokens-woocommerce-payment-gateway');
        $str_metamask_network_mismatch = __('MetaMask network mismatch. Choose another network or ask site administrator.', 'ether-and-erc20-tokens-woocommerce-payment-gateway');
        $network_failure_message = __('Failed to send transaction due to network error. Try again please.', 'ether-and-erc20-tokens-woocommerce-payment-gateway');

        // Output everything.
        ?>
    <section class="twbs epg-payment-instructions">
    <h2><?php echo $this->get_setting_('title', __('Pay with ETH', 'ether-and-erc20-tokens-woocommerce-payment-gateway')); ?></h2>
    <div id="epg-unlock-metamask-message-wrapper" class="alert alert-warning hidden" hidden role="alert">
        <!--http://jsfiddle.net/0vzmmn0v/1/-->
        <div class="fa fa-exclamation-triangle" aria-hidden="true"></div>
        <div><?php esc_html_e($str_unlock_metamask_account) ?></div>
    </div>
    <div id="epg-metamask-network-mismatch-message-wrapper" class="alert alert-warning hidden" hidden role="alert">
        <!--http://jsfiddle.net/0vzmmn0v/1/-->
        <div class="fa fa-exclamation-triangle" aria-hidden="true"></div>
        <div><?php esc_html_e($str_metamask_network_mismatch) ?></div>
    </div>
    <div id="epg-payment-incomplete-message-wrapper" class="alert alert-warning hidden" hidden role="alert">
        <!--http://jsfiddle.net/0vzmmn0v/1/-->
        <div class="fa fa-exclamation-triangle" aria-hidden="true"></div>
        <div><?php esc_html_e($payment_incomplete_message) ?></div>
    </div>
    <div id="epg-payment-deposit-made-message-wrapper" class="alert alert-warning hidden" hidden role="alert">
        <!--http://jsfiddle.net/0vzmmn0v/1/-->
        <div class="fa fa-exclamation-triangle" aria-hidden="true"></div>
        <div><?php esc_html_e($payment_deposit_made_message) ?></div>
    </div>
    <div id="epg-payment-success-message-wrapper" class="alert alert-success hidden" hidden role="alert">
        <!--http://jsfiddle.net/0vzmmn0v/1/-->
        <div class="fa fa-check-circle" aria-hidden="true"></div>
        <div><?php esc_html_e($success_message) ?></div>
    </div>
    <div id="epg-payment-success-no-metamask-message-wrapper" class="alert alert-success hidden" hidden role="alert">
        <!--http://jsfiddle.net/0vzmmn0v/1/-->
        <div class="fa fa-check-circle" aria-hidden="true"></div>
        <div><?php esc_html_e($success_message_no_metamask) ?></div>
    </div>
    <div id="epg-payment-network_failure-message-wrapper" class="alert alert-danger hidden" hidden role="alert">
        <!--http://jsfiddle.net/0vzmmn0v/1/-->
        <div class="fa fa-exclamation-triangle" aria-hidden="true"></div>
        <div><?php esc_html_e($network_failure_message) ?></div>
    </div>
    <?php
    $strDisplayStyle = '';
    if (empty(trim($tokens_supported))) {
        $strDisplayStyle = 'display:none;';
    }
    ?>
    <div class="container-fluid" id="epg-token-wrapper" style="padding-left: 0; padding-right: 0;<?php echo $strDisplayStyle; ?>">
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label class="control-label" for="epg-token"><?php _e('Choose Ether or ERC20 token', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></label>
                    <select name="epg-token" id="epg-token"
                            class="form-control">
<?php
        $disable_ether = $this->get_setting_('disable_ether', 'no');
        if ('yes' != $disable_ether) {
?>
                        <option value="ETH" selected>ETH</option>
<?php
        }
        $tokensArr = explode(",", $tokens_supported);
        if ($tokensArr) {
            foreach ($tokensArr as $tokenStr) {
                $tokenPartsArr = explode(":", $tokenStr);
                if (count($tokenPartsArr) != 3) {
                    continue;
                }
                $symbol = $tokenPartsArr[0];
                ?>
                        <option value="<?php echo $symbol ?>"><?php echo $symbol ?></option>
                <?php
            }
        }
?>
                    </select>
                </div>
            </div>
        </div>
    </div>
    <?php if (function_exists('ETHEREUM_WALLET_send_transaction') && get_current_user_id() > 0) { ?>
    <form method="post" action="">
    <?php } ?>
    <div class="container-fluid" style="padding-left: 0; padding-right: 0;" id="epg-ether-payment">
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label class="control-label" for="epg-ether-amount"><?php _e('Amount', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></label>
                    <div id="epg-ether-amount"><?php esc_html_e($eth_value_with_dust_str); ?></div>
                </div>
                <p>
                    <a class="pull-left" id="epg-ether-advanced-details-button" data-toggle="collapse" href="#epg-ether-advanced-details" role="button" aria-expanded="false" aria-controls="epg-ether-advanced-details"><?php _e('Advanced', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></a>
                </p>
                <div class="collapse" id="epg-ether-advanced-details">
                    <div class="form-group">
                        <label class="control-label" for="epg-ether-value"><?php _e('Value', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></label>
                        <div class="input-group" style="margin-top: 8px">
                            <input type="hidden" 
                                   value="<?php esc_html_e($eth_value_with_dust); ?>" 
                                   name="epg-ether-value-wei">
                            <input style="cursor: text;" type="text" readonly 
                                   value="<?php esc_html_e($eth_value_with_dust_str); ?>" 
                                   data-clipboard-action="copy" 
                                   id="epg-ether-value" 
                                   name="epg-ether-value" 
                                   class="form-control">
                            <span class="input-group-append">
                                <div class="btn-group" role="group">
                                    <button class="button btn btn-default btn-left d-md-inline" type="button" data-toggle="collapse" href="#epg-ether-qr1" role="button" aria-expanded="false" aria-controls="epg-ether-qr1" title="<?php _e('QR', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?>"><i class="fa fa-qrcode" aria-hidden="true"></i></button>
                                    <button class="button btn btn-default btn-right epg-copy-button" type="button"
                                            data-input-id="epg-ether-value"
                                            title="<?php _e('Copy', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?>">
                                        <i class="fa fa-clipboard" aria-hidden="true"></i>
                                    </button>
                                </div>
                            </span>
                        </div>
                        <div class="collapse" id="epg-ether-qr1">
                            <div class="d-md-block mx-auto col-md-4 float-none">
                                <div class="epg-ether-canvas-qr1"></div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label" for="epg-ether-gateway-address"><?php _e('Address', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></label>
                        <div class="input-group" style="margin-top: 8px">
                            <input style="cursor: text;" type="text" readonly 
                                   value="<?php echo $this->getGatewayContractAddress(); ?>" 
                                   data-clipboard-action="copy" 
                                   id="epg-ether-gateway-address" 
                                   name="epg-ether-gateway-address" 
                                   class="form-control">
                            <span class="input-group-append">
                                <div class="btn-group" role="group">
                                    <button class="button btn btn-default btn-left d-md-inline" type="button" data-toggle="collapse" href="#epg-ether-qr2" role="button" aria-expanded="false" aria-controls="epg-ether-qr2" title="<?php _e('QR', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?>"><i class="fa fa-qrcode" aria-hidden="true"></i></button>
                                    <button class="button btn btn-default btn-right epg-copy-button" type="button"
                                            data-input-id="epg-ether-gateway-address"
                                            title="<?php _e('Copy', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?>">
                                        <i class="fa fa-clipboard" aria-hidden="true"></i>
                                    </button>
                                </div>
                            </span>
                        </div>
                        <div class="collapse" id="epg-ether-qr2">
                            <div class="d-md-block mx-auto col-md-4 float-none">
                                <div class="epg-ether-canvas-qr2"></div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label" for="epg-ether-data-value"><?php _e('Data', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></label>
                        <div class="input-group" style="margin-top: 8px">
                            <input style="cursor: text;" type="text" readonly 
                                   value="<?php echo $this->getMarketAddress(); ?>" 
                                   data-clipboard-action="copy" 
                                   id="epg-ether-data-value" 
                                   name="epg-ether-data-value" 
                                   class="form-control">
                            <span class="input-group-append">
                                <div class="btn-group" role="group">
                                    <button class="button btn btn-default btn-left d-md-inline" type="button" data-toggle="collapse" href="#epg-ether-qr3" role="button" aria-expanded="false" aria-controls="epg-ether-qr3" title="<?php _e('QR', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?>"><i class="fa fa-qrcode" aria-hidden="true"></i></button>
                                    <button class="button btn btn-default btn-right epg-copy-button" type="button"
                                            data-input-id="epg-ether-data-value"
                                            title="<?php _e('Copy', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?>">
                                        <i class="fa fa-clipboard" aria-hidden="true"></i>
                                    </button>
                                </div>
                            </span>
                        </div>
                        <div class="collapse" id="epg-ether-qr3">
                            <div class="d-md-block mx-auto col-md-4 float-none">
                                <div class="epg-ether-canvas-qr3"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <button
                        id="epg-ether-mm-pay" 
                        class="button btn btn-default float-right col-12 col-md-4"
                        type="button"><?php _e('Pay with MetaMask', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></button>
                    <button 
                        id="epg-ether-download-metamask-button" 
                        class="button btn btn-default float-right hidden col-12 col-md-4" 
                        hidden
                        type="button"><?php _e('Download MetaMask!', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></button>
                    <?php 
                    if (function_exists('ETHEREUM_WALLET_send_transaction') && get_current_user_id() > 0) {
                        wp_nonce_field( 'ether-and-erc20-tokens-woocommerce-payment-gateway-send_form', 'ether-and-erc20-tokens-woocommerce-payment-gateway-send-form-nonce', true, true ); ?>
                    <input type="hidden" name="action" value="ether-and-erc20-tokens-woocommerce-payment-gateway_send" />
                    <input type="hidden" 
                           value="<?php esc_html_e($order_id); ?>" 
                           name="epg-order-id">
                    <button 
                        id="ether-and-erc20-tokens-woocommerce-payment-gateway-send-button" 
                        name="ether-and-erc20-tokens-woocommerce-payment-gateway-send-button" 
                        type="submit" 
                        value="<?php __('Pay with Ethereum Wallet', 'ether-and-erc20-tokens-woocommerce-payment-gateway') ?>" 
                        class="button btn btn-default float-right col-12 col-md-4"><?php _e('Pay with Ethereum Wallet', 'ether-and-erc20-tokens-woocommerce-payment-gateway') ?></button>
                    <?php } ?>
                    <div id="epg-ether-spinner" class="spinner float-right"></div>
                </div>
            </div>
        </div>
    </div>
    <?php if (function_exists('ETHEREUM_WALLET_send_transaction') && get_current_user_id() > 0) { ?>
    </form>
    <?php } ?>
    <div id="rootwizard-help-info" class="container-fluid" style="padding-left: 0; padding-right: 0;">
        <div class="row">
            <div class="col-md-12">
                <div class="alert alert-info" role="info">
                    <!--http://jsfiddle.net/0vzmmn0v/1/-->
                    <div class="fa fa-info-circle" aria-hidden="true"></div>
                    <div>
                        <span>
                            <?php esc_html_e($payment_summary_token_title) ?>
                            <a data-toggle="collapse" href="#epg-payment-token-help-info" role="button" aria-expanded="false" aria-controls="epg-payment-token-help-info"><?php _e('More...', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></a>
                        </span>
                        <div class="collapse" id="epg-payment-token-help-info">
                            <ol>
                                <li><?php esc_html_e($payment_summary_token_1) ?></li>
                                <li><?php esc_html_e($payment_summary_token_2) ?></li>
                            </ol>
                            <?php esc_html_e($payment_summary_token_3) ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php if (function_exists('ETHEREUM_WALLET_send_transaction') && get_current_user_id() > 0) { ?>
    <form method="post" action="">
    <?php } ?>
    <div id="rootwizard" class="hidden" hidden>
        <div class="container-fluid" style="padding-left: 0; padding-right: 0;">
            <div class="row">
                <div class="col-md-12">
                    <ul class="nav nav-pills nav-justified">
                        <li class="nav-item"><a class="nav-link" href="#epg-payment-step1" data-toggle="tab"><?php _e('1. Deposit funds', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></a></li>
                        <li class="nav-item"><a class="nav-link" href="#epg-payment-step2" data-toggle="tab"><?php _e('2. Make payment', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></a></li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane active" id="epg-payment-step1">
                            <div class="alert alert-info" role="info" style="margin-top:10px">
                                <!--http://jsfiddle.net/0vzmmn0v/1/-->
                                <div class="fa fa-info-circle" aria-hidden="true"></div>
                                <div>
                                    <span>
                                        <?php esc_html_e($deposit_description_title) ?>
                                        <a data-toggle="collapse" href="#epg-payment-step1-help-info" role="button" aria-expanded="false" aria-controls="epg-payment-step1-help-info"><?php _e('More...', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></a>
                                    </span>
                                    <div class="collapse" id="epg-payment-step1-help-info">
                                        <?php esc_html_e($deposit_description) ?>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label" for="epg-amount"><?php _e('Amount', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></label>
                                <div id="epg-amount"><?php esc_html_e($eth_value); ?></div>
                            </div>
                            <div id="epg-balance-group" class="form-group hidden" hidden 
                                >
                                <label class="control-label" for="epg-balance"><?php _e('Balance', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></label>
                                <input style="cursor: text;" type="text" readonly 
                                       value="0" 
                                       id="epg-balance" 
                                       name="epg-balance" 
                                       class="form-control">
                            </div>
                            <p>
                                <a class="pull-left" id="epg-token-advanced-details-step1-button" data-toggle="collapse" href="#epg-token-advanced-details-step1" role="button" aria-expanded="false" aria-controls="epg-token-advanced-details-step1"><?php _e('Advanced', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></a>
                            </p>
                            <div class="collapse" id="epg-token-advanced-details-step1">
                                <div class="form-group">
                                    <label class="control-label" for="epg-value"><?php _e('Value', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></label>
                                    <div class="input-group" style="margin-top: 8px">
                                        <input style="cursor: text;" type="text" readonly 
                                               value="0" 
                                               data-clipboard-action="copy" 
                                               id="epg-value" 
                                               name="epg-value" 
                                               class="form-control">
                                        <span class="input-group-append">
                                            <div class="btn-group" role="group">
                                                <button class="button btn btn-default btn-left d-md-inline" type="button" data-toggle="collapse" href="#epg-token-step1-qr1" role="button" aria-expanded="false" aria-controls="epg-token-step1-qr1" title="<?php _e('QR', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?>"><i class="fa fa-qrcode" aria-hidden="true"></i></button>
                                                <button class="button btn btn-default btn-right epg-copy-button" type="button"
                                                        data-input-id="epg-value"
                                                        title="<?php _e('Copy', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?>">
                                                    <i class="fa fa-clipboard" aria-hidden="true"></i>
                                                </button>
                                            </div>
                                        </span>
                                    </div>
                                    <div class="collapse" id="epg-token-step1-qr1">
                                        <div class="d-md-block mx-auto col-md-4 float-none">
                                            <div class="epg-token-step1-canvas-qr1"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="epg-gateway-address"><?php _e('Address', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></label>
                                    <div class="input-group" style="margin-top: 8px">
                                        <input style="cursor: text;" type="text" readonly 
                                               value="<?php echo $this->getGatewayContractAddress(); ?>" 
                                               data-clipboard-action="copy" 
                                               id="epg-gateway-address" 
                                               name="epg-gateway-address" 
                                               class="form-control">
                                        <span class="input-group-append">
                                            <div class="btn-group" role="group">
                                                <button class="button btn btn-default btn-left d-md-inline" type="button" data-toggle="collapse" href="#epg-token-step1-qr2" role="button" aria-expanded="false" aria-controls="epg-token-step1-qr2" title="<?php _e('QR', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?>"><i class="fa fa-qrcode" aria-hidden="true"></i></button>
                                                <button class="button btn btn-default btn-right epg-copy-button" type="button"
                                                        data-input-id="epg-gateway-address"
                                                        title="<?php _e('Copy', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?>">
                                                    <i class="fa fa-clipboard" aria-hidden="true"></i>
                                                </button>
                                            </div>
                                        </span>
                                    </div>
                                    <div class="collapse" id="epg-token-step1-qr2">
                                        <div class="d-md-block mx-auto col-md-4 float-none">
                                            <div class="epg-token-step1-canvas-qr2"></div>
                                        </div>
                                    </div>
                                </div>
                                <div id="epg-data-value-group" class="form-group hidden" hidden 
                                    >
                                    <label class="control-label" for="epg-data-value"><?php _e('Data', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></label>
                                    <div class="input-group" style="margin-top: 8px">
                                        <textarea style="cursor: text;" readonly 
                                                  data-clipboard-action="copy" 
                                                  id="epg-data-value" 
                                                  name="epg-data-value" 
                                                  class="form-control"></textarea>
                                        <span class="input-group-append">
                                            <div class="btn-group" role="group">
                                                <button class="button btn btn-default btn-left d-md-inline" type="button" data-toggle="collapse" href="#epg-token-step1-qr3" role="button" aria-expanded="false" aria-controls="epg-token-step1-qr3" title="<?php _e('QR', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?>"><i class="fa fa-qrcode" aria-hidden="true"></i></button>
                                                <button class="button btn btn-default btn-right epg-copy-button" type="button"
                                                        data-input-id="epg-data-value"
                                                        title="<?php _e('Copy', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?>">
                                                    <i class="fa fa-clipboard" aria-hidden="true"></i>
                                                </button>
                                            </div>
                                        </span>
                                    </div>
                                    <div class="collapse" id="epg-token-step1-qr3">
                                        <div class="d-md-block mx-auto col-md-4 float-none">
                                            <div class="epg-token-step1-canvas-qr3"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="epg-payment-step2">
                            <div class="alert alert-info" role="info" style="margin-top:10px">
                                <!--http://jsfiddle.net/0vzmmn0v/1/-->
                                <div class="fa fa-info-circle" aria-hidden="true"></div>
                                <div>
                                    <span>
                                        <?php esc_html_e($payment_description_title) ?>
                                        <a data-toggle="collapse" href="#epg-payment-step2-help-info" role="button" aria-expanded="false" aria-controls="epg-payment-step2-help-info"><?php _e('More...', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></a>
                                    </span>
                                    <div class="collapse" id="epg-payment-step2-help-info">
                                        <?php esc_html_e($payment_description) ?>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label" for="epg-amount2"><?php _e('Amount', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></label>
                                <div id="epg-amount2"><?php esc_html_e($eth_value); ?></div>
                            </div>
                            <p>
                                <a class="pull-left" id="epg-token-advanced-details-step2-button" data-toggle="collapse" href="#epg-token-advanced-details-step2" role="button" aria-expanded="false" aria-controls="epg-token-advanced-details-step2"><?php _e('Advanced', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></a>
                            </p>
                            <div class="collapse" id="epg-token-advanced-details-step2">
                                <div class="form-group">
                                    <label class="control-label" for="epg-value"><?php _e('Value', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></label>
                                    <div class="input-group" style="margin-top: 8px">
                                        <input style="cursor: text;" type="text" readonly 
                                               value="0" 
                                               data-clipboard-action="copy" 
                                               id="epg-value-step2" 
                                               name="epg-value-step2" 
                                               class="form-control">
                                        <span class="input-group-append">
                                            <div class="btn-group" role="group">
                                                <button class="button btn btn-default btn-left d-md-inline" type="button" data-toggle="collapse" href="#epg-token-step2-qr1" role="button" aria-expanded="false" aria-controls="epg-token-step2-qr1" title="<?php _e('QR', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?>"><i class="fa fa-qrcode" aria-hidden="true"></i></button>
                                                <button class="button btn btn-default btn-right epg-copy-button" type="button"
                                                        data-input-id="epg-value-step2"
                                                        title="<?php _e('Copy', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?>">
                                                    <i class="fa fa-clipboard" aria-hidden="true"></i>
                                                </button>
                                            </div>
                                        </span>
                                    </div>
                                    <div class="collapse" id="epg-token-step2-qr1">
                                        <div class="d-md-block mx-auto col-md-4 float-none">
                                            <div class="epg-token-step2-canvas-qr1"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="epg-gateway-address"><?php _e('Address', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></label>
                                    <div class="input-group" style="margin-top: 8px">
                                        <input style="cursor: text;" type="text" readonly 
                                               value="<?php echo $this->getGatewayContractAddress(); ?>" 
                                               data-clipboard-action="copy" 
                                               id="epg-gateway-address-step2" 
                                               name="epg-gateway-address-step2" 
                                               class="form-control">
                                        <span class="input-group-append">
                                            <div class="btn-group" role="group">
                                                <button class="button btn btn-default btn-left d-md-inline" type="button" data-toggle="collapse" href="#epg-token-step2-qr2" role="button" aria-expanded="false" aria-controls="epg-token-step2-qr2" title="<?php _e('QR', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?>"><i class="fa fa-qrcode" aria-hidden="true"></i></button>
                                                <button class="button btn btn-default btn-right epg-copy-button" type="button"
                                                        data-input-id="epg-gateway-address-step2"
                                                        title="<?php _e('Copy', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?>">
                                                    <i class="fa fa-clipboard" aria-hidden="true"></i>
                                                </button>
                                            </div>
                                        </span>
                                    </div>
                                    <div class="collapse" id="epg-token-step2-qr2">
                                        <div class="d-md-block mx-auto col-md-4 float-none">
                                            <div class="epg-token-step2-canvas-qr2"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label" for="epg-data-value"><?php _e('Data', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></label>
                                    <div class="input-group" style="margin-top: 8px">
                                        <textarea style="cursor: text;" readonly 
                                                  data-clipboard-action="copy" 
                                                  id="epg-data-value-step2" 
                                                  name="epg-data-value-step2" 
                                                  class="form-control"></textarea>
                                        <span class="input-group-append">
                                            <div class="btn-group" role="group">
                                                <button class="button btn btn-default btn-left d-md-inline" type="button" data-toggle="collapse" href="#epg-token-step2-qr3" role="button" aria-expanded="false" aria-controls="epg-token-step2-qr3" title="<?php _e('QR', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?>"><i class="fa fa-qrcode" aria-hidden="true"></i></button>
                                                <button class="button btn btn-default btn-right epg-copy-button" type="button"
                                                        data-input-id="epg-data-value-step2"
                                                        title="<?php _e('Copy', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?>">
                                                    <i class="fa fa-clipboard" aria-hidden="true"></i>
                                                </button>
                                            </div>
                                        </span>
                                    </div>
                                    <div class="collapse" id="epg-token-step2-qr3">
                                        <div class="d-md-block mx-auto col-md-4 float-none">
                                            <div class="epg-token-step2-canvas-qr3"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="container-fluid" style="padding-left: 0; padding-right: 0;">
                            <div class="row" style="width:100%; margin-left: 0; margin-right: 0;">
                                <button 
                                    id="epg-button-previous" 
                                    class="button btn btn-default previous hidden col-12 col-md-2" 
                                    hidden
                                    type="button"><?php _e('Previous', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></button>
                                <div id="epg-wizard-buttons-group" class="col-12 offset-md-2 col-md-10" style="padding-left: 0px;padding-right: 0px;">
                                    <button 
                                        id="epg-button-next" 
                                        class="button btn btn-default float-right col-md-2 col-sm-12"
                                        type="button"><?php _e('Next', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></button>
                                    <button 
                                        id="epg-download-metamask-button" 
                                        class="button btn btn-default hidden float-right col-md-4 col-sm-12" 
                                        hidden
                                        type="button"><?php _e('Download MetaMask!', 'ether-and-erc20-tokens-woocommerce-payment-gateway'); ?></button>
                                    <?php if (function_exists('ETHEREUM_WALLET_send_transaction') && get_current_user_id() > 0) {
                                        wp_nonce_field( 'ether-and-erc20-tokens-woocommerce-payment-gateway-send_form', 'ether-and-erc20-tokens-woocommerce-payment-gateway-send-form-nonce', true, true )?>
                                    <input type="hidden" name="action" value="ether-and-erc20-tokens-woocommerce-payment-gateway_send_token" />
                                    <input type="hidden" 
                                           value="<?php esc_html_e($order_id); ?>" 
                                           name="epg-order-id">
                                    <input type="hidden" 
                                           value="" 
                                           id="epg-token-step"
                                           name="epg-token-step">
                                    <button 
                                        id="ether-and-erc20-tokens-woocommerce-payment-gateway-send-token-button" 
                                        name="ether-and-erc20-tokens-woocommerce-payment-gateway-send-token-button" 
                                        type="submit" 
                                        value="<?php __('Deposit with Ethereum Wallet', 'ether-and-erc20-tokens-woocommerce-payment-gateway') ?>" 
                                        class="button btn btn-default float-right col-12 col-md-4"><?php _e('Pay with Ethereum Wallet', 'ether-and-erc20-tokens-woocommerce-payment-gateway') ?></button>
                                    <?php } ?>
                                    <div id="epg-spinner" class="spinner float-right"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php if (function_exists('ETHEREUM_WALLET_send_transaction') && get_current_user_id() > 0) { ?>
    </form>
    <?php } ?>
</section>
        <?php
            $base_url = $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->base_url;
            $min = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
            wp_enqueue_script(
                'wooetherc20paymentgateway', 
                $base_url . "/js/ether-and-erc20-tokens-woocommerce-payment-gateway{$min}.js", array('jquery', 'bootstrap.wizard', 'web3', 'jquery.qrcode'), '2.6.0'
            );
            wp_enqueue_style(
                'wooetherc20paymentgateway', 
                $base_url . "/css/ether-and-erc20-tokens-woocommerce-payment-gateway.css", array('bootstrap-ether-and-erc20-tokens-woocommerce-payment-gateway'), '2.6.0'
            );

            $web3Endpoint = $this->getWeb3Endpoint();
            
            if (function_exists('ETHEREUM_WALLET_send_transaction') && get_current_user_id() > 0) {
                list($lastTxHash, $lastTxTime) = ETHEREUM_WALLET_get_last_tx_hash_time();
            } else {
                list($lastTxHash, $lastTxTime) = ["", ""];
            }

            wp_localize_script(
                'wooetherc20paymentgateway', 'epg', [
                // variables
                'gas_limit' => esc_html(intval($this->get_setting_('gas_limit', '200000'))),
                'gas_price' => esc_html(floatval($this->get_setting_('gas_price', '21'))),
                'payment_address' => esc_html($this->get_setting_('payment_address')),
                'tokens_supported' => esc_html(ether_and_erc20_tokens_woocommerce_payment_gateway_get_tokens_supported($this->get_setting_('tokens_supported'), $order_id, $custom_currency)),
                'markup_percent' => esc_html($this->get_setting_('markup_percent', '0')),
                'markup_percent_token' => esc_html($this->get_setting_('markup_percent_token', '0')),
                'gateway_address_v1' => $this->getGatewayContractAddress_v1(),
                'gateway_abi_v1' => $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->gatewayContractABI_v1,
                'gateway_address' => $this->getGatewayContractAddress(),
                'gateway_abi' => $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->gatewayContractABI,
                'erc20_abi' => $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->erc20ContractABI,
                'eth_value' => esc_html($eth_value),
                'eth_value_with_dust' => esc_html($eth_value_with_dust),
                'order_id' => $order_id,
                'web3Endpoint' => esc_html($web3Endpoint),
                'blockchain_network' => esc_html($this->getBlockchainNetwork()),
                'user_wallet_address' => esc_html(function_exists('ETHEREUM_WALLET_send_transaction') ? ETHEREUM_WALLET_get_wallet_address() : ""),
                'user_wallet_last_txhash' => esc_html($lastTxHash),
                'user_wallet_last_txtime' => esc_html($lastTxTime),
                // translations
//                'str_page_unload_text' => __('Do not close or reload this page until payment confirmation complete.', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'str_make_deposit_button_text' => __('Deposit with MetaMask', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'str_make_deposit_with_ethereum_wallet_button_text' => __('Deposit with Ethereum Wallet', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'str_pay_button_text' => __('Pay with MetaMask', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'str_download_metamask' => __('Download MetaMask', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'str_download_metamask_or_input_address' => __('Download MetaMask or input your ethereum address', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'str_unlock_metamask_account' => __('Unlock your MetaMask account please.', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'str_pay_with_ethereum_wallet' =>  __('Pay with Ethereum Wallet', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'str_pay_eth_failure' => __('Failed to pay ETH with MetaMask', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'str_pay_eth_success' => __('Pay ETH with MetaMask succeeded', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'str_deposit_eth_failure' => __('Failed to deposit ETH with MetaMask', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'str_deposit_eth_success' => __('Deposit ETH with MetaMask succeeded', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'str_pay_token_failure' => __('Failed to pay ERC20 token with MetaMask', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'str_pay_token_failure_insufficient_balance' => __('Failed to pay ERC20 token: insufficient balance', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'str_pay_token_success' => __('Pay ERC20 token with MetaMask succeeded', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'str_pay_eth_rejected' => __('Failed to pay ETH with MetaMask - rejected', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'str_pay_token_rejected' => __('Failed to pay ERC20 token with MetaMask - rejected', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'str_deposit_token_failure' => __('Failed to deposit ERC20 token with MetaMask', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'str_deposit_token_failure_insufficient_balance' => __('Failed to deposit ERC20 token: insufficient balance', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'str_deposit_token_success' => __('Deposit ERC20 token with MetaMask succeeded', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'str_deposit_eth_rejected' => __('Failed to deposit ETH with MetaMask - rejected', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'str_deposit_token_rejected' => __('Failed to deposit ERC20 token with MetaMask - rejected', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'str_copied_msg' => __('Copied to clipboard', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'str_mm_site_connect_failed' => __('You have rejected the store to MetaMask connect request', 'ether-and-erc20-tokens-woocommerce-payment-gateway'),
                'str_payment_complete' => esc_html($success_message),
                'str_payment_complete_no_metamask' => esc_html($success_message_no_metamask),
                'str_payment_incomplete' => esc_html($payment_incomplete_message),
                'str_metamask_network_mismatch' => esc_html($str_metamask_network_mismatch),
                ]
            );
        }

        public function register_plugin_styles() {
            $base_url = $GLOBALS['ether-and-erc20-tokens-woocommerce-payment-gateway']->base_url;
            $min = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
            wp_dequeue_script('web3');
            wp_deregister_script('web3');
            wp_register_script(
                'web3', $base_url . "/js/web3{$min}.js", array('jquery'), '0.20.6'
            );

            if( ( ! wp_script_is( 'bootstrap', 'queue' ) ) && ( ! wp_script_is( 'bootstrap', 'done' ) ) ) {
                wp_dequeue_script('bootstrap');
                wp_deregister_script('bootstrap');
                wp_register_script(
                    'bootstrap', 
                    $base_url . "/js/bootstrap{$min}.js", array('jquery'), '4.0.0'
                );
            }

            if( ( ! wp_script_is( 'qrcode', 'queue' ) ) && ( ! wp_script_is( 'qrcode', 'done' ) ) ) {
                wp_dequeue_script('qrcode');
                wp_deregister_script('qrcode');
                wp_register_script(
                    'qrcode', 
                    $base_url . "/js/qrcode{$min}.js", array(), '2009'
                );
            }

            if( ( ! wp_script_is( 'jquery.qrcode', 'queue' ) ) && ( ! wp_script_is( 'jquery.qrcode', 'done' ) ) ) {
                wp_dequeue_script('jquery.qrcode');
                wp_deregister_script('jquery.qrcode');
                wp_register_script(
                    'jquery.qrcode', 
                    $base_url . "/js/jquery.qrcode{$min}.js", array('jquery', 'qrcode'), '1.0'
                );
            }

            if( ( ! wp_script_is( 'bootstrap.wizard', 'queue' ) ) && ( ! wp_script_is( 'bootstrap.wizard', 'done' ) ) ) {
                wp_dequeue_script('bootstrap.wizard');
                wp_deregister_script('bootstrap.wizard');
                wp_register_script(
                    'bootstrap.wizard', 
                    $base_url . "/js/jquery.bootstrap.wizard{$min}.js", array('jquery', 'bootstrap'), '1.4.2'
                );
            }

            if( ( ! wp_style_is( 'font-awesome', 'queue' ) ) && ( ! wp_style_is( 'font-awesome', 'done' ) ) ) {
                wp_dequeue_style('font-awesome');
                wp_deregister_style('font-awesome');
                wp_register_style(
                    'font-awesome', 
                    $base_url . "/css/font-awesome{$min}.css", array(), '4.7.0'
                );
            }

            if( ( ! wp_style_is( 'bootstrap-ether-and-erc20-tokens-woocommerce-payment-gateway', 'queue' ) ) && ( ! wp_style_is( 'bootstrap-ether-and-erc20-tokens-woocommerce-payment-gateway', 'done' ) ) ) {
                wp_dequeue_style('bootstrap-ether-and-erc20-tokens-woocommerce-payment-gateway');
                wp_deregister_style('bootstrap-ether-and-erc20-tokens-woocommerce-payment-gateway');
                wp_register_style(
                    'bootstrap-ether-and-erc20-tokens-woocommerce-payment-gateway', 
                    $base_url . "/css/bootstrap-ns{$min}.css", array('font-awesome'), '4.0.0'
                );
            }
        }
        
        protected function getGatewayContractAddress() {
            $blockchainNetwork = $this->getBlockchainNetwork();
            return ether_and_erc20_tokens_woocommerce_payment_gateway_getGatewayContractAddress($blockchainNetwork);
        }

        protected function getGatewayContractAddress_v1() {
            $blockchainNetwork = $this->getBlockchainNetwork();
            return ether_and_erc20_tokens_woocommerce_payment_gateway_getGatewayContractAddress_v1($blockchainNetwork);
        }

        public function getMarketAddress() {
            return esc_attr($this->get_setting_('payment_address'));
        }

        public function getOrderExpiredTimeout() {
            // TODO: use order_expire_timeout
            return 1 * 24 * 3600; // one day
//        return $this->settings['order_expire_timeout'];
        }

        protected function getWeb3Endpoint() {
            $infuraApiKey = esc_attr($this->get_setting_('infura_api_key'));
            $blockchainNetwork = $this->getBlockchainNetwork();
            $web3Endpoint = "https://" . esc_attr($blockchainNetwork) . ".infura.io/" . esc_attr($infuraApiKey);
            return $web3Endpoint;
        }

        protected function getBlockchainNetwork() {
            $blockchainNetwork = esc_attr($this->get_setting_('blockchain_network', 'mainnet'));
            if (empty($blockchainNetwork)) {
                $blockchainNetwork = 'mainnet';
            }
            return $blockchainNetwork;
        }

    }
    
