<?php

namespace Ethereumico\Epg;

class CurrencyRateSource_B2XDealerCurrencyAggregatorAPI implements ICurrencyRateSource {
    
    /**
     * The source name to use in the cache key
     * 
     * @return string The source name to use in the cache key
     */
    public function get_source_name() {
        return 'B2XDealerCurrencyAggregatorAPI';
    }

    /**
     * The used API limit in seconds.
     * Use to cache for that time
     * 
     * @return int The used API limit in seconds
     */
    public function get_api_limit_sec() {
        return 60;
    }

    /**
	 * Retrieve the exchange rate from the API.
	 *
	 * @throws \Exception    Throws exception on error.
	 *
	 * @return float  The exchange rate.
	 */
	public function get_rate_from_api($source, $destination) {
        global $wp_version;
        
        if ('EUR' != $source) {
            throw new \Exception( 'Only EUR destination is supported for the B2XDealerCurrencyAggregatorAPI rate source. The provided destination is ' . $source );
        }
        
        $url = 'https://api.iblockchainbank.eu/market/coin/' . strtolower($destination);
        $args = array(
            'timeout'     => 5,
            'redirection' => 5,
            'httpversion' => '1.1',
            'user-agent'  => 'WordPress/' . $wp_version . '; ' . home_url(),
            'blocking'    => true,
            'headers'     => array("Accept" => "*/*"),
            'cookies'     => array(),
            'body'        => null,
            'compress'    => false,
            'decompress'  => true,
            'sslverify'   => true,
            'stream'      => false,
            'filename'    => null
        ); 
		$response = wp_remote_get( $url, $args );
		if ( is_wp_error( $response ) || 200 !== $response['response']['code'] ) {
			throw new \Exception( 'Could not fetch ETH pricing' );
		}
		$body = json_decode( $response['body'] );
		if ( json_last_error() !== JSON_ERROR_NONE ) {
			throw new \Exception( 'Could not convert ETH pricing - JSON error.' );
		}
		if ( ! isset( $body->{"success"} ) || ! $body->{"success"} ) {
            if ( isset( $body->{"message"} ) ) {
                throw new \Exception( 'Could not convert ETH pricing - ' . $body->{"message"} );
            }
			throw new \Exception( 'Could not convert ETH pricing - missing value after decoding.' );
		}
		if ( ! isset( $body->{"result"} ) ) {
            if ( isset( $body->{"message"} ) ) {
                throw new \Exception( 'Could not convert ETH pricing - ' . $body->{"message"} );
            }
			throw new \Exception( 'Could not convert ETH pricing - missing result after decoding.' );
		}
        if ( ! isset( $body->{"result"}->{"buy"} ) ) {
            if ( isset( $body->{"message"} ) ) {
                throw new \Exception( 'Could not convert ETH pricing - ' . $body->{"message"} );
            }
			throw new \Exception( 'Could not convert ETH pricing - missing result.buy after decoding.' );
		}
		return 1.0 / (float) $body->{"result"}->{"buy"};
	}
}
