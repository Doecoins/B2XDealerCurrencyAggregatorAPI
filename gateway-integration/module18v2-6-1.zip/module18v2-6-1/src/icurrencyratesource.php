<?php

namespace Ethereumico\Epg;

interface ICurrencyRateSource {
	/**
	 * Retrieve the exchange rate from the API.
	 *
	 * @throws \Exception    Throws exception on error.
	 *
	 * @return float  The exchange rate.
	 */
	public function get_rate_from_api($source, $destination);
    
    /**
     * The used API limit in seconds.
     * Use to cache for that time
     * 
     * @return int The used API limit in seconds
     */
    public function get_api_limit_sec();
    
    /**
     * The source name to use in the cache key
     * 
     * @return string The source name to use in the cache key
     */
    public function get_source_name();
}
