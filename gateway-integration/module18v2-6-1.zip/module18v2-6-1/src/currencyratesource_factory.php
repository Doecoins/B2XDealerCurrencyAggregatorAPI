<?php

namespace Ethereumico\Epg;

class CurrencyRateSource_Factory {
    /**
     * 
     * @param string $strCurrencyRateSource The 'fiat_rate_provider' setting value
     * @param array $options Plugin settings array
     * @return \Ethereumico\Epg\ICurrencyRateSource The rate source object implementation
     * @throws \Exception
     */
    public static function create($strCurrencyRateSource, &$options) {
        switch ($strCurrencyRateSource) {
            case "fiat_rate_provider_cryptocompare_api_key" :
                $cryptocompareApiKey = esc_attr(isset($options['cryptocompare_api_key']) ? $options['cryptocompare_api_key'] : '');
                return new CurrencyRateSource_Cryptocompare($cryptocompareApiKey);
            case "fiat_rate_provider_B2XDealerCurrencyAggregatorAPI" :
                return new CurrencyRateSource_B2XDealerCurrencyAggregatorAPI;
            default :
                throw new \Exception( 'Unknown currency rate source option provided.' );
        }
    }
}
