<?php

namespace Ethereumico\Epg;

class CurrencyRateSource_Cryptocompare implements ICurrencyRateSource {

	/**
	 * The https://min-api.cryptocompare.com API Key
	 *
	 * @var string
	 */
	private $cryptocompareApiKey;

	/**
	 * Construct the class.
	 *
	 * @param string $cryptocompareApiKey The API Key for the min-api.cryptocompare.com
	 */
	public function __construct( $cryptocompareApiKey = '' ) {
		$this->cryptocompareApiKey = $cryptocompareApiKey;
	}

    /**
     * The source name to use in the cache key
     * 
     * @return string The source name to use in the cache key
     */
    public function get_source_name() {
        return 'Cryptocompare';
    }
    
    /**
     * The used API limit in seconds.
     * Use to cache for that time
     * 
     * @return int The used API limit in seconds
     */
    public function get_api_limit_sec() {
        return 1800;
    }
    
	/**
	 * Retrieve the exchange rate from the API.
	 *
	 * @throws \Exception    Throws exception on error.
	 *
	 * @return float  The exchange rate.
	 */
	public function get_rate_from_api($source, $destination) {
        global $wp_version;
        // https://min-api.cryptocompare.com/
        // fsym  REQUIRED The cryptocurrency symbol of interest [Max character length: 10]
        // tsyms REQUIRED Comma separated cryptocurrency symbols list to convert into [Max character length: 500]
        // extraParams The name of your application (we recommend you send it) [Max character length: 50]
        $appName = urlencode(substr(home_url(), 0, 50));
        if (empty($this->cryptocompareApiKey)) {
            $url = 'https://min-api.cryptocompare.com/data/price?fsym=' . $source . '&tsyms=' . $destination . '&extraParams=' . $appName;
        } else {
            $url = 'https://min-api.cryptocompare.com/data/price?fsym=' . $source . '&tsyms=' . $destination . '&extraParams=' . $appName . '&api_key=' . $this->cryptocompareApiKey;
        }
        $args = array(
            'timeout'     => 5,
            'redirection' => 5,
            'httpversion' => '1.1',
            'user-agent'  => 'WordPress/' . $wp_version . '; ' . home_url(),
            'blocking'    => true,
            'headers'     => array("Accept" => "*/*"),
            'cookies'     => array(),
            'body'        => null,
            'compress'    => false,
            'decompress'  => true,
            'sslverify'   => true,
            'stream'      => false,
            'filename'    => null
        ); 
		$response = wp_remote_get( $url, $args );
		if ( is_wp_error( $response ) || 200 !== $response['response']['code'] ) {
			throw new \Exception( 'Could not fetch ETH pricing' );
		}
		$body = json_decode( $response['body'] );
		if ( json_last_error() !== JSON_ERROR_NONE ) {
			throw new \Exception( 'Could not convert ETH pricing - JSON error.' );
		}
		if ( ! isset( $body->{$destination} ) ) {
            if ( isset( $body->{"Message"} ) ) {
                throw new \Exception( 'Could not convert ETH pricing - ' . $body->{"Message"} );
            }
			throw new \Exception( 'Could not convert ETH pricing - missing value after decoding.' );
		}
		return (float) $body->{$destination};
	}
}
