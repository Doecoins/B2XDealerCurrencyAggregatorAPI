<?php

namespace Ethereumico\Epg;

use Ethereumico\Epg\PaymentReceivedEmail;
use \WC_Logger;
use \WC_Order;

class Main {

	/**
	 * The base URL of the plugin.
	 *
	 * @var string
	 */
	public $base_url;

	/**
	 * The base path of the plugin files.
	 *
	 * @var string
	 */
	public $base_path;

    /**
     * The Gateway smart contract ABI
     * 
     * @var string The Gateway smart contract ABI
     * @see http://www.webtoolkitonline.com/json-minifier.html
     */
    public $gatewayContractABI = '[{"constant":false,"inputs":[{"name":"_tokenAddress","type":"address"},{"name":"_sellerAddress","type":"address"},{"name":"_orderId","type":"uint256"},{"name":"_value","type":"uint256"}],"name":"payToken","outputs":[{"name":"success","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_feeAccount1","type":"address"}],"name":"setFeeAccount1","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_feeAccount2","type":"address"}],"name":"setFeeAccount2","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_feeAccountToken","type":"address"}],"name":"setFeeAccountToken","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_feePercent","type":"uint256"}],"name":"setFeePercent","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[],"name":"transferFee","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"payable":true,"stateMutability":"payable","type":"fallback"},{"inputs":[],"payable":false,"stateMutability":"nonpayable","type":"constructor"},{"constant":true,"inputs":[],"name":"balanceOfEthFee","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_tokenAddress","type":"address"},{"name":"_Address","type":"address"}],"name":"balanceOfToken","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"feeAccount1","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"feeAccount2","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"feeAccountToken","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"feePercent","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_sellerAddress","type":"address"},{"name":"_orderId","type":"uint256"}],"name":"getBuyerAddressPayment","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_sellerAddress","type":"address"},{"name":"_orderId","type":"uint256"}],"name":"getCurrencyPayment","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_sellerAddress","type":"address"},{"name":"_orderId","type":"uint256"}],"name":"getSellerAddressPayment","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_sellerAddress","type":"address"},{"name":"_orderId","type":"uint256"}],"name":"getValuePayment","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"maxFee","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"owner","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"},{"name":"","type":"uint256"}],"name":"payment","outputs":[{"name":"buyerAddress","type":"address"},{"name":"sellerAddress","type":"address"},{"name":"value","type":"uint256"},{"name":"currency","type":"address"}],"payable":false,"stateMutability":"view","type":"function"}]';
    
    /**
     * The Gateway smart contract ABI v1
     * 
     * @var string The Gateway smart contract ABI
     * @see http://www.webtoolkitonline.com/json-minifier.html
     */
    public $gatewayContractABI_v1 = '[{"constant":true,"inputs":[],"name":"maxFee","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_sellerAddress","type":"address"},{"name":"_orderId","type":"uint256"}],"name":"getSellerAddressPayment","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_sellerAddress","type":"address"},{"name":"_orderId","type":"uint256"}],"name":"getBuyerAddressPayment","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"}],"name":"balances","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_feeAccountToken","type":"address"}],"name":"setFeeAccountToken","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"_sellerAddress","type":"address"},{"name":"_orderId","type":"uint256"}],"name":"getValuePayment","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"balanceOfEthFee","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[],"name":"refund","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"","type":"address"},{"name":"","type":"uint256"}],"name":"payment","outputs":[{"name":"buyerAddress","type":"address"},{"name":"sellerAddress","type":"address"},{"name":"value","type":"uint256"},{"name":"currency","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"feeAccount2","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_feePercent","type":"uint256"}],"name":"setFeePercent","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"feePercent","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_sellerAddress","type":"address"},{"name":"_orderId","type":"uint256"},{"name":"_value","type":"uint256"}],"name":"payEth","outputs":[{"name":"success","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"owner","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_sellerAddress","type":"address"},{"name":"_orderId","type":"uint256"}],"name":"getCurrencyPayment","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"getBalanceEth","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"feeAccount1","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[],"name":"transferFee","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_feeAccount1","type":"address"}],"name":"setFeeAccount1","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_feeAccount2","type":"address"}],"name":"setFeeAccount2","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"feeAccountToken","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"_tokenAddress","type":"address"},{"name":"_Address","type":"address"}],"name":"balanceOfToken","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_tokenAddress","type":"address"},{"name":"_sellerAddress","type":"address"},{"name":"_orderId","type":"uint256"},{"name":"_value","type":"uint256"}],"name":"payToken","outputs":[{"name":"success","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"inputs":[],"payable":false,"stateMutability":"nonpayable","type":"constructor"},{"payable":true,"stateMutability":"payable","type":"fallback"}]';
    
    /**
     * The ERC20 smart contract ABI
     * 
     * @var string The ERC20 smart contract ABI
     * @see http://www.webtoolkitonline.com/json-minifier.html
     */
    public $erc20ContractABI = '[{"constant":true,"inputs":[],"name":"totalSupply","outputs":[{"name":"supply","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"name","outputs":[{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"decimals","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"}],"name":"balanceOf","outputs":[{"name":"balance","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_owner","type":"address"},{"name":"_spender","type":"address"}],"name":"allowance","outputs":[{"name":"remaining","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"anonymous":false,"inputs":[{"indexed":true,"name":"_owner","type":"address"},{"indexed":true,"name":"_spender","type":"address"},{"indexed":false,"name":"_value","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"_from","type":"address"},{"indexed":true,"name":"_to","type":"address"},{"indexed":false,"name":"_value","type":"uint256"}],"name":"Transfer","type":"event"},{"constant":false,"inputs":[{"name":"_spender","type":"address"},{"name":"_value","type":"uint256"}],"name":"approve","outputs":[{"name":"success","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transfer","outputs":[{"name":"success","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_from","type":"address"},{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transferFrom","outputs":[{"name":"success","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"}]';
    
	/**
	 * Constructor.
	 *
	 * Store variables for use later.
	 *
	 * @param string $base_url  The base URL of the plugin.
	 */
	function __construct( $base_url, $base_path ) {
		$this->base_url = $base_url;
		$this->base_path = $base_path;
	}

	/**
	 * Trigger the plugin to run.
	 */
	public function run() {
		add_action( 'plugins_loaded', array( $this, 'on_plugins_loaded' ) );
		add_action( 'init', array( $this, 'on_init' ) );
		add_filter( 'woocommerce_email_classes', array( $this, 'register_eth_payment_completed_email' ) );
		add_action( 'woocommerce_email_order_details', array( $this, 'email_content' ), 1, 4 );
        // add on-hold status to a list of statuses that needs payment
        add_filter('woocommerce_valid_order_statuses_for_payment', array($this, 'valid_order_statuses_for_payment'), 10, 2);
	}

	/**
	 * Designed to run actions required at WordPress' init hook.
	 *
	 * Triggers localisation of the plugin.
	 */
	public function on_init() {
        // ETHEREUM_WALLET plugin integration
        if (function_exists('ETHEREUM_WALLET_send_transaction') && get_current_user_id() > 0) {
            add_action( 'wp_loaded', array($this, 'wp_loaded_hook'), 20 );
        }
	}
    
    public function valid_order_statuses_for_payment($statuses = array()) {
        if (!$statuses) {
            $statuses = array('pending', 'failed');
        }
        array_push($statuses, 'on-hold');
        // expired orders are marked as failed
        // it is important to skip them from processing
        // to clean up cron tasks for them
        $statuses = array_filter($statuses, function ($s) {
            return $s != 'failed';
        });
        $statuses = array_values($statuses);
//        $this->log("statuses: " . print_r($statuses, true));
        return $statuses;
    }

    public function wp_loaded_hook() {
        global $wp;
        
//        $gateways = WC_Payment_Gateways::instance()->payment_gateways();
//        if (!gateways) {
//            return;
//        }
//        if (!isset($gateways['ether-and-erc20-tokens-woocommerce-payment-gateway'])) {
//            return;
//        }
//        $this_ = $gateways['ether-and-erc20-tokens-woocommerce-payment-gateway'];

        if ( 'POST' !== strtoupper( $_SERVER['REQUEST_METHOD'] ) ) {
            return;
        }
        if ( empty( $_POST['action'] ) ) {
            return;
        }
        if ( 
            'ether-and-erc20-tokens-woocommerce-payment-gateway_send' !== $_POST['action'] && 
            'ether-and-erc20-tokens-woocommerce-payment-gateway_send_token' !== $_POST['action']
        ) {
            return;
        }
        if (function_exists('wc_nocache_headers')) {
            wc_nocache_headers();
        } else {
            nocache_headers();
        }
        $nonce_value = '';
        if (isset($_REQUEST['ether-and-erc20-tokens-woocommerce-payment-gateway-send-form-nonce'])) {
            $nonce_value = $_REQUEST['ether-and-erc20-tokens-woocommerce-payment-gateway-send-form-nonce'];
        } else if (isset($_REQUEST['_wpnonce'])) {
            $nonce_value = $_REQUEST['_wpnonce'];
        }
        if ( ! wp_verify_nonce( $nonce_value, 'ether-and-erc20-tokens-woocommerce-payment-gateway-send_form' ) ) {
            $this->log("wp_loaded_hook sendform_action: bad nonce detected: " . $nonce_value);
            return;
        }
        $user_id = get_current_user_id();
        if ( $user_id <= 0 ) {
            $this->log("ether_and_erc20_tokens_woocommerce_payment_gateway_wp_loaded_hook bad user_id: " . $user_id);
            return;
        }
        
        list($lastTxHash, $lastTxTime) = ETHEREUM_WALLET_get_last_tx_hash_time();
        if (!empty($lastTxHash)) {
            $this->log("wp_loaded_hook sendform_action: last tx is in progress. skip action: " . $_POST['action']);
            return;
        }
        
        switch ($_POST['action']) {
            case 'ether-and-erc20-tokens-woocommerce-payment-gateway_send':
                $this->process_hook_('epg-ether-gateway-address', 'epg-ether-value-wei', 'epg-ether-data-value');
                break;
            
            case 'ether-and-erc20-tokens-woocommerce-payment-gateway_send_token':
                if (isset($_POST['epg-token-step'])) {
                    switch ($_POST['epg-token-step']) {
                        case '0':
                            // TODO: epg-value is in ETH, not in wei, but it is always 0 here
                            $this->process_hook_('epg-gateway-address', 'epg-value', 'epg-data-value');
                            break;

                        case '1':
                            // TODO: epg-value-step2 is in ETH, not in wei, but it is always 0 here
                            $this->process_hook_('epg-gateway-address-step2', 'epg-value-step2', 'epg-data-value-step2');
                            break;

                        default:
                            $this->log("wp_loaded_hook sendform_action: unsupported epg-token-step detected: " . $_POST['epg-token-step']);
                            break;
                    }
                } else {
                        $this->log("wp_loaded_hook sendform_action: epg-token-step is not set");
                }
                break;

            default:
                $this->log("wp_loaded_hook sendform_action: unsupported action detected: " . $_POST['action']);
                break;
        }
    }
    
    private function process_hook_($to_field_name, $value_field_name, $data_field_name) {
        global $wp;
//        $this->log("process_hook_($to_field_name, $value_field_name, $data_field_name)");
        // order_id
//        id="epg-order-id" 

        if (!isset( $_REQUEST['epg-order-id'] )) {
            $this->log("process_hook_: epg-order-id not set");
            return;
        }

        if (!is_numeric( $_REQUEST['epg-order-id'] )) {
            $this->log("process_hook_: epg-order-id is not numeric");
            return;
        }

        $order_id = sanitize_text_field($_REQUEST['epg-order-id']);
        if (empty( $order_id )) {
            $this->log("process_hook_: empty epg-order-id");
            return;
        }

        $order_id = intval($order_id);

        $order = new WC_Order($order_id);
        if (!$order->needs_payment()) {
            $this->log('Order do not need payment, action cancelled: ' . $order_id);
            return;
        }

        ////////////////////////////

        // To address
//        id="epg-ether-gateway-address" 

        if (!isset( $_REQUEST[$to_field_name] )) {
            $this->log("process_hook_: epg-ether-gateway-address not set");
            return;
        }

        $to = sanitize_text_field($_REQUEST[$to_field_name]);
        if (empty( $to )) {
            $this->log("process_hook_: empty epg-ether-gateway-address");
            return;
        }

        if (42 != strlen( $to )) {
            $this->log("process_hook_: strlen epg-ether-gateway-address != 42: " . $to);
            return;
        }

        if ('0x' != substr( $to, 0, 2 )) {
            $this->log("process_hook_: startsWith epg-ether-gateway-address != 0x: " . $to);
            return;
        }

        // Amount
//        id="epg-ether-value-wei" 

        if (!isset( $_REQUEST[$value_field_name] )) {
            $this->log("process_hook_: $value_field_name not set");
            return;
        }

        if (!is_numeric( $_REQUEST[$value_field_name] )) {
            $this->log("process_hook_: non-numeric $value_field_name: " . $amount_wei);
            return;
        }

//        $this->log("$value_field_name: $_REQUEST[$value_field_name]");
        $amount_wei = sanitize_text_field($_REQUEST[$value_field_name]);
        $amount_wei = intval($amount_wei);

        // Currency address
//        id="epg-ether-data-value" 

        if (!isset( $_REQUEST[$data_field_name] )) {
            $this->log("process_hook_: epg-ether-data-value not set");
            return;
        }

        $data = sanitize_text_field($_REQUEST[$data_field_name]);
        if (empty( $data )) {
            $this->log("process_hook_: empty epg-ether-data-value");
            return;
        }

        if ('0x' != substr( $data, 0, 2 )) {
            $this->log("process_hook_: startsWith epg-ether-data-value != 0x: " . $to);
            return;
        }

        $txhash = ETHEREUM_WALLET_send_transaction($to, $amount_wei, $data);
        $this->log("process_hook_ sendform_action: ETHEREUM_WALLET_send_transaction(to: $to, amount: $amount_wei, data: $data) -> $txhash");

        if (false !== $txhash) {
            $blockchainNetwork = $this->getBlockchainNetwork();
            // TODO: different messages for approve and payToken calls
            $this->set_order_txhash($order_id, $txhash, $blockchainNetwork);
    ?>
        <script>
            if ( window.history.replaceState ) {
                window.history.replaceState( null, null, window.location.href );
            }
        </script>
    <?php
        } else {
    ?>
        <script>
            document.addEventListener("DOMContentLoaded", function(event) { 
                setTimeout(function(){
                    var element = document.getElementById("epg-payment-network_failure-message-wrapper");
                    if (element) {
                        element.classList.remove("hidden");
                        element.removeAttribute("hidden");
                    }
                }, 1000);
            });
        </script>
    <?php
        }

    }
    
    public function getBlockchainNetwork() {
        global $CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options;
        $blockchainNetwork = 'mainnet';
        if (!isset($CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options['blockchain_network'])) {
            return $blockchainNetwork;
        }
        if (empty($CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options['blockchain_network'])) {
            return $blockchainNetwork;
        }
        $blockchainNetwork = esc_attr($CRYPTOCURRENCY_PRODUCT_FOR_WOOCOMMERCE_options['blockchain_network']);
        return $blockchainNetwork;
    }
    
    public function set_order_txhash($order_id, $txHash, $blockchainNetwork) {
        $txHashPath = '';
        switch ($blockchainNetwork) {
            case 'mainnet':
                $txHashPath = 'https://etherscan.io/tx/' . $txHash;
                break;
            case 'ropsten':
                $txHashPath = 'https://ropsten.etherscan.io/tx/' . $txHash;
                break;
            case 'rinkeby':
                $txHashPath = 'https://rinkeby.etherscan.io/tx/' . $txHash;
                break;
            default:
                break;
        }
        $order = new WC_Order($order_id);
        $order->add_order_note(
            sprintf(
                __('Sent to blockchain. Transaction hash <a href="%1$s">%2$s</a>.', 'cryptocurrency-product-for-woocommerce')
                , $txHashPath
                , $txHash
            )
        );
        update_post_meta( $order_id, 'txhash', sanitize_text_field( $txHash ) );
    }

	/**
	 * Designed to run actions required at WordPress' plugins_loaded hook.
	 *
	 * - Register our gateway with WooCommerce.
	 */
	public function on_plugins_loaded() {
	    if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
			return;
		}
	    add_filter( 'woocommerce_payment_gateways', array( $this, 'add_gateway' ) );
	}

	/**
	 * Register our payment completed email.
	 */
	public function register_eth_payment_completed_email( $email_classes ) {
		$email_classes['PWE_Payment_Completed'] = new PaymentReceivedEmail();
		return $email_classes;
	}

	/**
	 * Add the Gateway to WooCommerce.
	 *
	 * @param array $gateways  The current list of gateways.
	 */
	public function add_gateway( $gateways ) {
		$gateways[] = 'Ethereumico\Epg\Gateway';
		return $gateways;
	}

	/**
	 * Add payment instructions to the "order on hold" email.
	 */
	public function email_content( $order, $sent_to_admin, $plain_text, $email ) {
		// We only interfere in the order on hold email.
		if ( ! ( $email instanceof \WC_Email_Customer_On_Hold_Order ) ) {
			return;
		}
		// Check that the order was paid with this gateway.
		if ( is_callable( array( $order, 'get_payment_method' ) ) ) {
			$payment_method = $order->get_payment_method();
		} else {
			$payment_method = $order->payment_method;
		}
		if ( 'ether-and-erc20-tokens-woocommerce-payment-gateway' !== $payment_method ) {
			return;
		}
		// Retrieve the info we need.
		$settings  = get_option( 'woocommerce_ether-and-erc20-tokens-woocommerce-payment-gateway_settings', false );
		if ( is_callable( array( $order, 'get_id' ) ) ) {
			$order_id = $order->get_id();
		} else {
			$order_id = $order->id;
		}
		$eth_value = get_post_meta( $order_id, '_epg_eth_value', true );
		if ( false === $settings || false === $eth_value ) {
			return;
		}
		?>
		<h2>
		<?php
		esc_html_e( __('Payment details', 'ether-and-erc20-tokens-woocommerce-payment-gateway') );
		?>
		</h2>
		<ul>
			<li><?php _e( 'Amount', 'ether-and-erc20-tokens-woocommerce-payment-gateway' ); ?>: <strong><?php esc_html_e( $eth_value ); ?></strong> ETH</li>
			<li><?php _e( 'Address', 'ether-and-erc20-tokens-woocommerce-payment-gateway' ); ?>: <strong><?php esc_html_e( $settings['payment_address'] ); ?></strong></li>
		</ul>
		<?php
	}

	/**
	 * Log information using the WC_Logger class.
	 *
	 * Will do nothing unless debug is enabled.
	 *
	 * @param string $msg   The message to be logged.
	 */
	public function log( $msg ) {
		static $logger = false;
		$settings  = get_option( 'woocommerce_ether-and-erc20-tokens-woocommerce-payment-gateway_settings', false );
		// Bail if debug isn't on.
		if ( 'yes' !== $settings['debug'] ) {
			return;
		}
		// Create a logger instance if we don't already have one.
		if ( false === $logger ) {
			$logger = new WC_Logger();
		}
		$logger->add( 'ether-and-erc20-tokens-woocommerce-payment-gateway', $msg );
	}


}
